// Edit navigation, stats and blog posts here — components read from this file.

export const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About Us", href: "#about" },
  { label: "Nanihal", href: "#nanihal" },
  { label: "Gallery", href: "#gallery" },
  { label: "Blog", href: "#blog" },
  {
    label: "Get Involved",
    children: [
      { label: "Volunteer with us", href: "#volunteer", note: "Teach, mentor or help at a centre" },
      { label: "Partner with us", href: "#partner", note: "CSR and builder partnerships" },
      { label: "Events", href: "#events", note: "Drives, camps and celebrations" },
      { label: "Annual reports", href: "#reports", note: "How your donations are used" },
    ],
  },
  { label: "Contact Us", href: "#contact" },
];

export const stats = [
  { icon: "Users", value: "100+", label: "Children reached" },
  { icon: "Heart", value: "Community", label: "focused" },
  { icon: "BookOpen", value: "Education", label: "& well-being" },
];

export const posts = [
  {
    title: "A day at a Nanihal centre",
    excerpt: "From morning prayers to afternoon naps — what a regular day looks like for the children on site.",
    date: "12 Sep 2026",
    tag: "Stories",
    image: "/images/nanihal-centre.jpg",
  },
  {
    title: "Why nutrition comes before the alphabet",
    excerpt: "A hungry child can't learn. How our meal programme supports early education.",
    date: "28 Aug 2026",
    tag: "Health",
    image: "/images/hero-children.jpg",
  },
  {
    title: "Working with builders to open safe spaces",
    excerpt: "How construction companies can host a childcare centre right at the worksite.",
    date: "05 Aug 2026",
    tag: "Partnerships",
    image: "/images/nanihal-centre.jpg",
  },
];

import { LazyMotion, domAnimation, MotionConfig } from "framer-motion";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import Nanihal from "./components/Nanihal.jsx";
import AboutYAF from "./components/AboutYAF.jsx";
import BlogPreview from "./components/BlogPreview.jsx";
import Footer from "./components/Footer.jsx";

// LazyMotion + "m" components load only the animation features we use (~15kb),
// instead of the full framer-motion bundle.
export default function App() {
  return (
    <LazyMotion features={domAnimation} strict>
      <MotionConfig reducedMotion="user">
        <Navbar />
        <main>
          <Hero />
          <Nanihal />
          <AboutYAF />
          <BlogPreview />
        </main>
        <Footer />
      </MotionConfig>
    </LazyMotion>
  );
}

import { useEffect, useRef, useState } from "react";
import { m, AnimatePresence } from "framer-motion";
import { Heart, Menu, X, ChevronDown } from "lucide-react";
import { navLinks } from "../data/site.js";

function Logo() {
  return (
    <a href="#home" className="flex items-center gap-2.5 sm:gap-3">
      <img src="/images/yaf-logo.png" alt="" width="48" height="48" className="h-10 w-10 rounded-full sm:h-12 sm:w-12" />
      <span className="leading-tight">
        <span className="block text-sm font-semibold tracking-tight text-ink sm:text-base">Yogishem Alliance Foundation</span>
        <span className="block text-[11px] text-ink/60 sm:text-xs">Nurturing Futures, Transforming Lives</span>
      </span>
    </a>
  );
}

function Dropdown({ item }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const close = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    const esc = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", esc);
    };
  }, []);

  return (
    <li ref={ref} className="relative" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-ink/80 transition-colors hover:text-plum-700"
      >
        {item.label}
        <ChevronDown className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      <AnimatePresence>
        {open && (
          <m.ul
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.18 }}
            className="absolute right-0 top-full z-50 w-72 rounded-xl border border-plum-100 bg-white p-2 shadow-xl shadow-plum-900/10"
          >
            {item.children.map((c) => (
              <li key={c.label}>
                <a href={c.href} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2.5 hover:bg-plum-50">
                  <span className="block text-sm font-medium text-ink">{c.label}</span>
                  <span className="block text-xs text-ink/60">{c.note}</span>
                </a>
              </li>
            ))}
          </m.ul>
        )}
      </AnimatePresence>
    </li>
  );
}

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("#home");
  const [subOpen, setSubOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Highlight the nav item for the section on screen
  useEffect(() => {
    const ids = navLinks.filter((l) => l.href).map((l) => l.href.slice(1));
    const els = ids.map((id) => document.getElementById(id)).filter(Boolean);
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive("#" + e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
  }, [mobileOpen]);

  const closeMobile = () => {
    setMobileOpen(false);
    setSubOpen(false);
  };

  return (
    <header
      className={`sticky top-0 z-40 bg-white/90 backdrop-blur-md transition-shadow ${
        scrolled ? "shadow-[0_1px_0_0_rgba(110,26,102,0.12)]" : ""
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:h-20 sm:px-6 lg:px-8" aria-label="Main">
        <Logo />

        <ul className="hidden items-center gap-1 xl:flex">
          {navLinks.map((item) =>
            item.children ? (
              <Dropdown key={item.label} item={item} />
            ) : (
              <li key={item.label}>
                <a
                  href={item.href}
                  aria-current={active === item.href ? "page" : undefined}
                  className={`relative block rounded-md px-3 py-2 text-sm font-medium transition-colors hover:text-plum-700 ${
                    active === item.href ? "text-plum-700" : "text-ink/80"
                  }`}
                >
                  {item.label}
                  {active === item.href && (
                    <m.span layoutId="nav-underline" className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-plum-700" />
                  )}
                </a>
              </li>
            )
          )}
        </ul>

        <div className="flex items-center gap-2">
          <a
            href="#donate"
            className="hidden items-center gap-2 rounded-lg bg-plum-700 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-plum-800 sm:inline-flex"
          >
            <Heart className="h-4 w-4 fill-current" /> Donate Now
          </a>
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="rounded-lg p-2 text-ink xl:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </nav>

      {/* Mobile / tablet drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <m.div
              className="fixed inset-0 z-50 bg-plum-900/40 xl:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeMobile}
            />
            <m.aside
              role="dialog"
              aria-modal="true"
              aria-label="Menu"
              className="fixed right-0 top-0 z-50 flex h-dvh w-[86%] max-w-sm flex-col bg-white shadow-2xl xl:hidden"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="flex h-16 items-center justify-between border-b border-plum-100 px-5">
                <span className="font-serif text-lg font-semibold text-plum-700">Menu</span>
                <button type="button" onClick={closeMobile} className="rounded-lg p-2" aria-label="Close menu">
                  <X className="h-6 w-6" />
                </button>
              </div>
              <ul className="flex-1 overflow-y-auto px-3 py-4">
                {navLinks.map((item) =>
                  item.children ? (
                    <li key={item.label}>
                      <button
                        type="button"
                        onClick={() => setSubOpen((v) => !v)}
                        aria-expanded={subOpen}
                        className="flex w-full items-center justify-between rounded-lg px-3 py-3 text-base font-medium text-ink"
                      >
                        {item.label}
                        <ChevronDown className={`h-5 w-5 transition-transform ${subOpen ? "rotate-180" : ""}`} />
                      </button>
                      <AnimatePresence initial={false}>
                        {subOpen && (
                          <m.ul
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden pl-3"
                          >
                            {item.children.map((c) => (
                              <li key={c.label}>
                                <a href={c.href} onClick={closeMobile} className="block rounded-lg px-3 py-2.5 text-sm text-ink/75 hover:bg-plum-50">
                                  {c.label}
                                </a>
                              </li>
                            ))}
                          </m.ul>
                        )}
                      </AnimatePresence>
                    </li>
                  ) : (
                    <li key={item.label}>
                      <a
                        href={item.href}
                        onClick={closeMobile}
                        className={`block rounded-lg px-3 py-3 text-base font-medium ${
                          active === item.href ? "bg-plum-50 text-plum-700" : "text-ink"
                        }`}
                      >
                        {item.label}
                      </a>
                    </li>
                  )
                )}
              </ul>
              <div className="border-t border-plum-100 p-5">
                <a
                  href="#donate"
                  onClick={closeMobile}
                  className="flex items-center justify-center gap-2 rounded-lg bg-plum-700 py-3 font-semibold text-white"
                >
                  <Heart className="h-4 w-4 fill-current" /> Donate Now
                </a>
              </div>
            </m.aside>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}

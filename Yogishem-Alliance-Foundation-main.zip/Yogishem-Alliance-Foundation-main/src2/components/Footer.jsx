import { Heart, Mail, Phone, MapPin } from "lucide-react";
import { navLinks } from "../data/site.js";

export default function Footer() {
  const flat = navLinks.flatMap((l) => (l.children ? l.children : [l]));
  return (
    <footer id="contact" className="bg-plum-900 text-white/80">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-3">
            <img src="/images/yaf-logo.png" alt="" loading="lazy" className="h-12 w-12 rounded-full bg-white" />
            <p className="font-serif text-lg font-semibold text-white">Yogishem Alliance Foundation</p>
          </div>
          <p className="mt-4 max-w-sm leading-relaxed">
            Education, health and care for the children of construction workers — so every child gets a fair chance to
            learn, grow and dream.
          </p>
          <a href="#donate" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-white px-5 py-2.5 font-semibold text-plum-800 hover:bg-plum-50">
            <Heart className="h-4 w-4 fill-current" /> Donate Now
          </a>
        </div>

        <nav aria-label="Footer">
          <h3 className="font-semibold text-white">Explore</h3>
          <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm sm:grid-cols-1">
            {flat.map((l) => (
              <li key={l.label}>
                <a href={l.href} className="hover:text-white">{l.label}</a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h3 className="font-semibold text-white">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex gap-3"><MapPin className="h-5 w-5 shrink-0" /> Add your office address here</li>
            <li className="flex gap-3"><Phone className="h-5 w-5 shrink-0" /> <a href="tel:+910000000000" className="hover:text-white">+91 00000 00000</a></li>
            <li className="flex gap-3"><Mail className="h-5 w-5 shrink-0" /> <a href="mailto:info@example.org" className="hover:text-white">info@example.org</a></li>
          </ul>
        </div>
      </div>
      <p className="border-t border-white/10 py-5 text-center text-xs text-white/50">
        © {new Date().getFullYear()} Yogishem Alliance Foundation. All rights reserved.
      </p>
    </footer>
  );
}

import { m } from "framer-motion";
import { ArrowRight, Sprout } from "lucide-react";
import Reveal from "./Reveal.jsx";

export default function Nanihal() {
  return (
    <section id="nanihal" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8 lg:py-24">
      <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
        <Reveal>
          <p className="font-serif text-2xl text-ink sm:text-3xl">What is</p>
          <span className="mt-2 inline-block rounded-full bg-plum-100 px-3 py-1 text-sm font-medium text-plum-700">
            Our initiative
          </span>
          <h2 className="mt-2 font-serif text-5xl font-bold text-plum-700 sm:text-6xl lg:text-7xl">Nanihal?</h2>
          <p className="mt-3 font-semibold text-plum-600">Flagship Initiative by Yogishem Alliance Foundation (YAF)</p>
          <p className="mt-5 max-w-xl leading-relaxed text-ink/75">
            Nanihal is a dedicated program to support the holistic development of children of construction workers. We
            focus on early education, health, hygiene, nutrition and a safe environment so every child gets a fair
            chance to learn, grow and dream.
          </p>
          <a
            href="#nanihal-more"
            className="group mt-8 inline-flex items-center gap-2 rounded-lg bg-plum-700 px-6 py-3 font-semibold text-white transition-colors hover:bg-plum-800"
          >
            Read More <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </a>
        </Reveal>

        <Reveal delay={0.15} className="relative">
          <div className="absolute -right-4 -top-6 hidden h-44 w-44 rounded-full bg-plum-100 sm:block" aria-hidden />
          <img
            src="/images/nanihal-centre.jpg"
            alt="Children playing with balloons outside a Nanihal centre"
            loading="lazy"
            className="relative aspect-[4/3] w-full rounded-2xl object-cover shadow-xl shadow-plum-900/10"
          />
          <m.img
            src="/images/yaf-logo.png"
            alt="Yogishem Alliance Foundation logo"
            loading="lazy"
            className="absolute -right-2 -top-8 h-24 w-24 rounded-full border-4 border-white bg-white shadow-lg sm:-right-6 sm:h-32 sm:w-32"
            whileHover={{ rotate: 12 }}
          />
          <Sprout className="absolute -bottom-6 -right-2 h-10 w-10 text-forest-600/50" aria-hidden />
        </Reveal>
      </div>
    </section>
  );
}

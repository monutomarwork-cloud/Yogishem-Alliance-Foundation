import { m } from "framer-motion";

// Small, one-time scroll reveal. Animates only opacity/transform (GPU friendly).
export default function Reveal({ children, delay = 0, y = 24, className = "", as = "div" }) {
  const Tag = m[as];
  return (
    <Tag
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </Tag>
  );
}

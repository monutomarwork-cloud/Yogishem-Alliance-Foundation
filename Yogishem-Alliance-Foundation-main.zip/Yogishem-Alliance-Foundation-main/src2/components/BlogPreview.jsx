import { ArrowRight } from "lucide-react";
import Reveal from "./Reveal.jsx";
import { posts } from "../data/site.js";

export default function BlogPreview() {
  return (
    <section id="blog" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8 lg:py-24">
      <Reveal className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="font-serif text-3xl font-bold text-ink sm:text-4xl">From our blog</h2>
          <p className="mt-2 max-w-lg text-ink/70">Stories and updates from our centres, volunteers and families.</p>
        </div>
        <a href="#blog-all" className="group inline-flex items-center gap-2 font-semibold text-plum-700">
          View all posts <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </a>
      </Reveal>

      <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {posts.map((p, i) => (
          <Reveal key={p.title} delay={i * 0.08} as="article" className={i === 2 ? "sm:col-span-2 lg:col-span-1" : ""}>
            <a href="#blog-post" className="group block">
              <div className="overflow-hidden rounded-2xl">
                <img
                  src={p.image}
                  alt=""
                  loading="lazy"
                  className="aspect-[16/10] w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <p className="mt-4 text-sm text-ink/60">
                <span className="font-medium text-plum-700">{p.tag}</span>
                <span className="mx-2">/</span>
                <time>{p.date}</time>
              </p>
              <h3 className="mt-1 font-serif text-xl font-semibold text-ink transition-colors group-hover:text-plum-700">{p.title}</h3>
              <p className="mt-2 leading-relaxed text-ink/70">{p.excerpt}</p>
            </a>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

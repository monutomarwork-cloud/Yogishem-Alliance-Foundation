import { m } from "framer-motion";
import { Heart, ArrowRight, Sun } from "lucide-react";

const ease = [0.22, 1, 0.36, 1];
const container = { hidden: {}, show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } } };
const item = { hidden: { opacity: 0, y: 28 }, show: { opacity: 1, y: 0, transition: { duration: 0.7, ease } } };

export default function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-b from-plum-50/70 to-white">
      {/* Photo: full-width on mobile, right-side bleed on large screens */}
      <m.div
        className="relative h-64 w-full sm:h-80 lg:absolute lg:inset-y-0 lg:right-0 lg:h-auto lg:w-[58%]"
        initial={{ opacity: 0, scale: 1.06 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.1, ease }}
      >
        <img
          src="/images/hero-children.jpg"
          alt="Smiling children of construction workers at a Nanihal learning centre"
          className="h-full w-full object-cover object-[35%_center]"
          fetchPriority="high"
        />
        {/* soft fade into the text column */}
        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/10 to-transparent lg:bg-gradient-to-r lg:from-plum-50 lg:via-plum-50/40 lg:to-transparent" />
        {/* Brush badge */}
        <m.div
          className="absolute bottom-14 right-4 sm:bottom-16 sm:right-8 lg:bottom-10 lg:right-8"
          initial={{ opacity: 0, rotate: -8, scale: 0.8 }}
          animate={{ opacity: 1, rotate: -4, scale: 1 }}
          transition={{ delay: 0.9, type: "spring", stiffness: 180, damping: 14 }}
        >
          <div className="relative rounded-[28px_10px_32px_12px] bg-plum-700 px-4 py-2.5 font-hand text-lg leading-5 text-white shadow-xl sm:px-6 sm:py-4 sm:text-2xl sm:leading-7 lg:text-[1.75rem] lg:leading-8">
            <Sun className="absolute -right-3 -top-4 h-8 w-8 text-sun sm:h-10 sm:w-10" strokeWidth={2.2} />
            Nurturing
            <br />
            Futures,
            <br /> Transforming
            <br />
            Lives
          </div>
        </m.div>
      </m.div>

      <div className="relative mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8 lg:py-28 xl:py-32">
        <m.div variants={container} initial="hidden" animate="show" className="-mt-6 max-w-xl lg:mt-0 lg:max-w-[40rem]">
          <m.p variants={item} className="mb-4 inline-flex items-center gap-2 rounded-full bg-plum-100 px-3 py-1 text-xs font-medium text-plum-700 sm:text-sm">
            <Heart className="h-3.5 w-3.5 fill-current" /> Welcome to Yogishem Alliance Foundation
          </m.p>

          <h1 className="font-serif text-[2.1rem] font-bold leading-[1.12] text-ink sm:text-5xl lg:text-[3.25rem]">
            <m.span variants={item} className="block">
              Building <span className="text-plum-700">Brighter</span>
            </m.span>
            <m.span variants={item} className="block">
              <span className="text-plum-700">Futures</span> for Children
            </m.span>
            <m.span variants={item} className="block">of Construction Workers</m.span>
          </h1>

          <m.p variants={item} className="mt-5 max-w-lg text-base leading-relaxed text-ink/75 sm:text-lg">
            We provide education, care, and essential support to underprivileged children, helping them grow into
            healthier, happier and brighter individuals.
          </m.p>

          <m.div variants={item} className="mt-8 flex flex-col gap-3 sm:flex-row sm:gap-4">
            <a
              href="#donate"
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-plum-700 px-7 py-3.5 font-semibold text-white shadow-lg shadow-plum-700/25 transition-colors hover:bg-plum-800"
            >
              <Heart className="h-4 w-4 fill-current" /> Donate Now
            </a>
            <a
              href="#nanihal"
              className="group inline-flex items-center justify-center gap-2 rounded-lg border-2 border-plum-200 bg-white px-7 py-3.5 font-semibold text-plum-700 transition-colors hover:border-plum-700"
            >
              Learn About Nanihal
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
          </m.div>
        </m.div>
      </div>

    </section>
  );
}

import { Target, Eye, Quote } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Img from "../components/ui/Img.jsx";
import Icon from "../components/ui/Icon.jsx";
import Button from "../components/ui/Button.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";
import { img } from "../data/images.js";
import { team, journey, values } from "../data/pages.js";

export default function About() {
  usePageTitle("About Us");
  return (
    <>
      {/* 1. Hero */}
      <PageHero
        crumb="About Us"
        title="Every child on a worksite deserves"
        highlight="a childhood."
        text="Yogishem Alliance Foundation is a non-profit working with the families of construction workers to give their youngest children care, food, learning and safety."
        image={img.community}
      >
        <Button to="/nanihal" variant="white" arrow>Explore Nanihal</Button>
      </PageHero>

      {/* 2. Our story */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal className="relative">
            <Img src={img.localCentre} alt="Children at the first Nanihal centre" className="aspect-[4/5] w-full rounded-[2rem] object-cover sm:aspect-[4/3] lg:aspect-[4/5]" />
            <div className="absolute -bottom-6 -right-2 max-w-[16rem] rounded-2xl bg-white p-5 shadow-xl shadow-plum-900/10 sm:-right-6">
              <Quote className="h-6 w-6 text-plum-500" />
              <p className="mt-2 font-serif text-lg leading-snug text-ink">"We started with twenty children and one room."</p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <SectionHeading eyebrow="Our story" title="Why we" highlight="started" align="left" />
            <div className="mt-6 space-y-4 leading-relaxed text-ink/75">
              <p>Every day, thousands of construction workers across the NCR bring their children to work because there is nowhere else for them to go. Toddlers spend their days next to cement mixers and open pits, without meals, medical care or anyone to teach them.</p>
              <p>We founded Yogishem Alliance Foundation to change that — by bringing safe, joyful childcare right to where these families live and work.</p>
              <p>Today, through our flagship initiative Nanihal, we care for around 100 children every day and work with builders, companies and volunteers to reach many more.</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 3. Mission & vision */}
      <section className="bg-plum-50/60 py-16 sm:py-24">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 sm:px-6 md:grid-cols-2 lg:px-8">
          <Reveal className="rounded-[2rem] bg-plum-700 p-8 text-white sm:p-10">
            <Target className="h-10 w-10 text-sun" strokeWidth={1.6} />
            <h2 className="mt-5 font-serif text-3xl font-bold">Our mission</h2>
            <p className="mt-3 text-lg leading-relaxed text-white/80">To give every child of a construction worker a safe place to spend the day, nutritious food, basic healthcare and a strong start in learning.</p>
          </Reveal>
          <Reveal delay={0.1} className="rounded-[2rem] bg-forest-700 p-8 text-white sm:p-10">
            <Eye className="h-10 w-10 text-sun" strokeWidth={1.6} />
            <h2 className="mt-5 font-serif text-3xl font-bold">Our vision</h2>
            <p className="mt-3 text-lg leading-relaxed text-white/80">An India where no child grows up on a worksite without care — and where every builder sees childcare as part of building responsibly.</p>
          </Reveal>
        </div>
      </section>

      {/* 4. Values */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <SectionHeading eyebrow="What guides us" title="Our" highlight="values" />
        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v, i) => (
            <Reveal as="li" key={v.title} delay={i * 0.06} className="rounded-3xl border border-plum-100 bg-white p-7">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-plum-50"><Icon name={v.icon} className="h-6 w-6 text-plum-700" /></span>
              <h3 className="mt-5 text-lg font-semibold text-ink">{v.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/65">{v.text}</p>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* 5. Journey timeline */}
      <section className="bg-plum-900 py-16 text-white sm:py-24">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="Our journey" title="How far" highlight="we've come" light />
          <ol className="relative mt-14 space-y-10 before:absolute before:bottom-2 before:left-[1.1rem] before:top-2 before:w-px before:bg-white/20 md:before:left-1/2">
            {journey.map((j, i) => (
              <Reveal as="li" key={j.year} className={`relative grid gap-2 pl-12 md:w-1/2 md:pl-0 ${i % 2 ? "md:ml-auto md:pl-12" : "md:pr-12 md:text-right"}`}>
                <span className={`absolute left-2 top-1 h-4 w-4 rounded-full border-4 border-plum-900 bg-sun ring-2 ring-sun/40 ${i % 2 ? "md:-left-2" : "md:left-auto md:-right-2"}`} aria-hidden />
                <span className="font-serif text-3xl font-bold text-plum-200">{j.year}</span>
                <h3 className="text-lg font-semibold">{j.title}</h3>
                <p className="text-white/70">{j.text}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* 6. Team */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <SectionHeading eyebrow="Our people" title="Meet the" highlight="team" text="A small team of educators, health workers and organisers who show up for the children every day." />
        <ul className="mt-12 grid grid-cols-2 gap-5 lg:grid-cols-4">
          {team.map((t, i) => (
            <Reveal as="li" key={t.name} delay={i * 0.06} className="group">
              <div className="overflow-hidden rounded-3xl">
                <Img src={t.photo} alt={t.name} className="aspect-[4/5] w-full object-cover grayscale-[30%] transition duration-500 group-hover:scale-105 group-hover:grayscale-0" />
              </div>
              <h3 className="mt-4 font-semibold text-ink">{t.name}</h3>
              <p className="text-sm text-plum-700">{t.role}</p>
            </Reveal>
          ))}
        </ul>
      </section>

      <CTABanner title="Be part of our story" text="Volunteer your time, partner with us, or sponsor a child's care." cta="Get Involved" to="/volunteer" />
    </>
  );
}

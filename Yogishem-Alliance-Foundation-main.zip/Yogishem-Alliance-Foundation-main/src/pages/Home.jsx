import usePageTitle from "../hooks/usePageTitle.js";
import Hero from "../components/home/Hero.jsx";
import NanihalIntro from "../components/home/NanihalIntro.jsx";
import AboutBand from "../components/home/AboutBand.jsx";
import Focus from "../components/home/Focus.jsx";
import Impact from "../components/home/Impact.jsx";
import Support from "../components/home/Support.jsx";
import GalleryStrip from "../components/home/GalleryStrip.jsx";
import ChildhoodCTA from "../components/home/ChildhoodCTA.jsx";
import BlogPreview from "../components/home/BlogPreview.jsx";
import Supporters from "../components/home/Supporters.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";

export default function Home() {
  usePageTitle();
  return (
    <>
      <Hero />
      <NanihalIntro />
      <AboutBand />
      <Focus />
      <Impact />
      <Support />
      <GalleryStrip />
      <ChildhoodCTA />
      <Supporters />
      <BlogPreview />
      <div className="pt-16 sm:pt-24" />
      <CTABanner />
    </>
  );
}

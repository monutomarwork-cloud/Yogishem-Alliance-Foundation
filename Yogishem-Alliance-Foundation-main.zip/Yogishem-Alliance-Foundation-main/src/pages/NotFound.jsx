import usePageTitle from "../hooks/usePageTitle.js";
import Button from "../components/ui/Button.jsx";

export default function NotFound() {
  usePageTitle("Page not found");
  return (
    <section className="mx-auto flex min-h-[70vh] max-w-xl flex-col items-center justify-center px-4 py-20 text-center">
      <p className="font-serif text-8xl font-bold text-plum-200">404</p>
      <h1 className="mt-4 font-serif text-3xl font-bold text-ink">This page doesn't exist</h1>
      <p className="mt-3 text-ink/65">The link may be broken or the page may have moved. Go back to the home page or see what's happening at Nanihal.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Button to="/">Go to home page</Button>
        <Button to="/nanihal" variant="outline">About Nanihal</Button>
      </div>
    </section>
  );
}

import { useState } from "react";
import { m, AnimatePresence } from "framer-motion";
import { CalendarDays, MapPin } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Img from "../components/ui/Img.jsx";
import Button from "../components/ui/Button.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";
import Newsletter from "../components/ui/Newsletter.jsx";
import { img } from "../data/images.js";
import { events } from "../data/pages.js";

const fmt = (d, opts) => new Date(d + "T00:00:00").toLocaleDateString("en-IN", opts);
const today = new Date().toISOString().slice(0, 10);

function DateBadge({ date, light }) {
  return (
    <span className={`grid w-16 shrink-0 place-items-center rounded-2xl py-2 text-center ${light ? "bg-white text-plum-800" : "bg-plum-700 text-white"}`}>
      <span className="text-xs font-medium uppercase">{fmt(date, { month: "short" })}</span>
      <span className="font-serif text-2xl font-bold leading-none">{fmt(date, { day: "2-digit" })}</span>
    </span>
  );
}

export default function Events() {
  usePageTitle("Events");
  const upcoming = events.filter((e) => e.date >= today).sort((a, b) => a.date.localeCompare(b.date));
  const past = events.filter((e) => e.date < today).sort((a, b) => b.date.localeCompare(a.date));
  const types = ["All", ...new Set(upcoming.map((e) => e.type))];
  const [type, setType] = useState("All");
  const [next, ...rest] = upcoming;
  const list = rest.filter((e) => type === "All" || e.type === type);

  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Events" title="Celebrate, give and" highlight="show up." text="Festivals with the children, donation drives, health camps and volunteer meet-ups — find one near you." image={img.kidsSmiling} />

      {/* 2. Next event spotlight */}
      {next && (
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
          <Reveal className="grid overflow-hidden rounded-[2rem] bg-plum-900 text-white lg:grid-cols-2">
            <Img src={next.image} alt="" className="aspect-[16/10] h-full w-full object-cover" />
            <div className="flex flex-col justify-center p-8 sm:p-12">
              <span className="w-fit rounded-full bg-sun px-3 py-1 text-xs font-semibold text-ink">Next event</span>
              <h2 className="mt-4 font-serif text-3xl font-bold sm:text-4xl">{next.title}</h2>
              <p className="mt-3 text-white/75">{next.text}</p>
              <ul className="mt-6 space-y-2 text-sm text-white/85">
                <li className="flex items-center gap-2"><CalendarDays className="h-4 w-4 text-plum-200" /> {fmt(next.date, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</li>
                <li className="flex items-center gap-2"><MapPin className="h-4 w-4 text-plum-200" /> {next.place}</li>
              </ul>
              <Button to="/contact" variant="white" arrow className="mt-8 self-start">Register interest</Button>
            </div>
          </Reveal>
        </section>
      )}

      {/* 3. Upcoming list with filter */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8">
        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <SectionHeading eyebrow="Upcoming" title="More coming" highlight="up" align="left" />
          <div className="flex flex-wrap gap-2">
            {types.map((t) => (
              <button key={t} onClick={() => setType(t)} aria-pressed={type === t} className={`rounded-full px-4 py-2 text-sm font-medium ${type === t ? "bg-plum-700 text-white" : "bg-plum-50 text-ink/70 hover:text-plum-700"}`}>{t}</button>
            ))}
          </div>
        </div>
        <m.ul layout className="mt-10 space-y-4">
          <AnimatePresence mode="popLayout">
            {list.map((e) => (
              <m.li key={e.id} layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex flex-col gap-5 rounded-3xl border border-plum-100 bg-white p-5 sm:flex-row sm:items-center sm:p-6">
                <DateBadge date={e.date} />
                <div className="flex-1">
                  <span className="text-xs font-semibold text-forest-700">{e.type}</span>
                  <h3 className="text-lg font-semibold text-ink">{e.title}</h3>
                  <p className="mt-1 text-sm text-ink/65">{e.text}</p>
                  <p className="mt-2 flex items-center gap-1.5 text-sm text-ink/55"><MapPin className="h-4 w-4" /> {e.place}</p>
                </div>
                <Button to="/contact" variant="outline" className="self-start px-5 py-2.5 text-sm sm:self-center">Join</Button>
              </m.li>
            ))}
          </AnimatePresence>
        </m.ul>
        {list.length === 0 && <p className="mt-10 rounded-3xl bg-plum-50 p-8 text-center text-ink/70">No other upcoming {type.toLowerCase()} events right now. Subscribe below to hear about new ones.</p>}
      </section>

      {/* 4. Past highlights */}
      <section className="bg-plum-50/60 py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="Past events" title="Recent" highlight="highlights" />
          <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {past.map((e, i) => (
              <Reveal as="li" key={e.id} delay={i * 0.06} className="group relative overflow-hidden rounded-3xl">
                <Img src={e.image} alt="" className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-plum-900/90 via-plum-900/20 to-transparent p-6 text-white">
                  <span className="text-xs text-plum-200">{fmt(e.date, { day: "numeric", month: "long", year: "numeric" })}</span>
                  <h3 className="font-serif text-xl font-bold">{e.title}</h3>
                  <p className="mt-1 text-sm text-white/75">{e.text}</p>
                </div>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* 5. Newsletter */}
      <Newsletter />

      <CTABanner title="Host a drive or fundraiser" text="Schools, offices and societies can run a collection drive for Nanihal. We'll help you plan it." cta="Plan with us" to="/contact" />
    </>
  );
}

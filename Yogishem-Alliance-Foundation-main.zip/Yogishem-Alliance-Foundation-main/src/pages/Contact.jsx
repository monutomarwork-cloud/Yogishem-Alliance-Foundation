import { MapPin, Phone, Mail, Clock } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import useForm, { required, email, fakeSend } from "../hooks/useForm.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Button from "../components/ui/Button.jsx";
import Field from "../components/ui/Field.jsx";
import FAQ from "../components/ui/FAQ.jsx";
import SuccessMessage from "../components/ui/SuccessMessage.jsx";
import SocialIcon from "../components/ui/SocialIcon.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";
import { img } from "../data/images.js";
import { contact, socials } from "../data/site.js";
import { faqs } from "../data/faqs.js";

const topics = ["General question", "Donation", "Volunteering", "Partnership / CSR", "Visit a centre", "Media"];

export default function Contact() {
  usePageTitle("Contact Us");
  const form = useForm(
    { name: "", email: "", topic: topics[0], message: "" },
    { name: required("name"), email, message: required("message") }
  );

  const cards = [
    { icon: Phone, title: "Call us", value: contact.phone, href: contact.phoneHref },
    { icon: Mail, title: "Email us", value: contact.email, href: `mailto:${contact.email}` },
    { icon: MapPin, title: "Visit us", value: contact.address },
    { icon: Clock, title: "Office hours", value: contact.hours },
  ];

  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Contact Us" title="We'd love to" highlight="hear from you." text="Questions about donating, volunteering, partnering or visiting a centre — write to us and we'll reply within 2 working days." image={img.handsTogether} />

      {/* 2. Contact cards */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c, i) => (
            <Reveal as="li" key={c.title} delay={i * 0.06}>
              <a href={c.href} className={`block h-full rounded-3xl border border-plum-100 bg-white p-6 transition-colors ${c.href ? "hover:border-plum-700" : "pointer-events-none"}`}>
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-plum-700 text-white"><c.icon className="h-5 w-5" /></span>
                <h3 className="mt-5 text-sm font-medium text-ink/60">{c.title}</h3>
                <p className="mt-1 break-words font-semibold text-ink">{c.value}</p>
              </a>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* 3. Form + map */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
          <Reveal className="rounded-[2rem] bg-plum-50/70 p-6 sm:p-10">
            <h2 className="font-serif text-3xl font-bold text-ink">Send a message</h2>
            <p className="mt-2 text-ink/65">All fields are required.</p>
            {form.status === "done" ? (
              <SuccessMessage title="Message sent" text="Thanks for writing to us. We'll reply within 2 working days." onReset={form.reset} />
            ) : (
              <form onSubmit={form.handleSubmit(fakeSend)} noValidate className="mt-8 grid gap-5 sm:grid-cols-2">
                <Field label="Name" {...form.bind("name")} autoComplete="name" />
                <Field label="Email" type="email" {...form.bind("email")} autoComplete="email" />
                <Field label="Topic" as="select" options={topics} className="sm:col-span-2" {...form.bind("topic")} />
                <Field label="Message" as="textarea" className="sm:col-span-2" {...form.bind("message")} />
                <Button type="submit" className="sm:col-span-2" disabled={form.status === "sending"}>{form.status === "sending" ? "Sending…" : "Send message"}</Button>
              </form>
            )}
          </Reveal>
          <Reveal delay={0.1} className="flex flex-col gap-6">
            <div className="flex-1 overflow-hidden rounded-[2rem] border border-plum-100">
              <iframe
                title="Map showing Yogishem Alliance Foundation in Noida"
                src={`https://www.google.com/maps?q=${encodeURIComponent(contact.mapQuery)}&output=embed`}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-72 w-full lg:h-full lg:min-h-[320px]"
              />
            </div>
            <div className="rounded-[2rem] bg-plum-800 p-6 text-white">
              <h3 className="font-semibold">Follow our work</h3>
              <ul className="mt-4 flex flex-wrap gap-2">
                {socials.map((s) => (
                  <li key={s.name}><a href={s.href} target="_blank" rel="noreferrer" aria-label={s.name} className="grid h-11 w-11 place-items-center rounded-xl bg-white/10 hover:bg-white hover:text-plum-800"><SocialIcon name={s.icon} /></a></li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </section>

      {/* 4. Visit a centre */}
      <section className="bg-forest-700 py-16 text-white sm:py-20">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <SectionHeading eyebrow="Visits" title="Come and see a" highlight="Nanihal centre" text="Donors, partners and volunteers are welcome to visit by appointment. For the children's safety, please book at least 2 days ahead and carry a photo ID." align="left" light />
          <Reveal className="grid grid-cols-3 gap-3 text-center">
            {[["Mon–Sat", "Visiting days"], ["10–12", "Visiting hours"], ["2 days", "Book ahead"]].map(([v, l]) => (
              <div key={l} className="rounded-3xl bg-white/10 p-5">
                <p className="font-serif text-2xl font-bold sm:text-3xl">{v}</p>
                <p className="mt-1 text-xs text-white/70 sm:text-sm">{l}</p>
              </div>
            ))}
          </Reveal>
        </div>
      </section>

      {/* 5. FAQ */}
      <FAQ items={faqs.contact} />

      <CTABanner title="Prefer to help right away?" text="A monthly gift of ₹1,000 feeds one child for a whole month." cta="Donate Now" to="/donate" />
    </>
  );
}

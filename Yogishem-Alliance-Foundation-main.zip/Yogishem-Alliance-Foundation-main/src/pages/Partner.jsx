import usePageTitle from "../hooks/usePageTitle.js";
import useForm, { required, email, phone, fakeSend } from "../hooks/useForm.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Icon from "../components/ui/Icon.jsx";
import Button from "../components/ui/Button.jsx";
import Field from "../components/ui/Field.jsx";
import StepList from "../components/ui/StepList.jsx";
import SuccessMessage from "../components/ui/SuccessMessage.jsx";
import Supporters from "../components/home/Supporters.jsx";
import { img } from "../data/images.js";
import { partnerModels, partnerBenefits, partnerSteps } from "../data/pages.js";

const types = ["Builder / developer", "Company (CSR)", "Foundation / trust", "Other"];

export default function Partner() {
  usePageTitle("Partner with us");
  const form = useForm(
    { org: "", name: "", email: "", phone: "", type: types[0], message: "" },
    { org: required("organisation name"), name: required("name"), email, phone }
  );

  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Partner with us" title="Build responsibly." highlight="Build for children too." text="Builders, companies and foundations partner with us to run safe childcare centres at worksites and fund early childhood programmes." image={img.teamMeeting}>
        <Button href="#enquire" variant="white" arrow>Start a conversation</Button>
      </PageHero>

      {/* 2. Partnership models */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <SectionHeading eyebrow="Ways to partner" title="Three ways to" highlight="work together" />
        <ul className="mt-12 grid gap-5 md:grid-cols-3">
          {partnerModels.map((p, i) => (
            <Reveal as="li" key={p.title} delay={i * 0.08} className="group relative overflow-hidden rounded-[2rem] border border-plum-100 bg-white p-8 transition-colors hover:border-plum-700">
              <span className="absolute right-6 top-6 rounded-full bg-plum-50 px-3 py-1 text-xs font-semibold text-plum-700">{p.tag}</span>
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-plum-700 text-white transition-transform group-hover:-rotate-6"><Icon name={p.icon} className="h-7 w-7" /></span>
              <h3 className="mt-6 font-serif text-2xl font-bold text-ink">{p.title}</h3>
              <p className="mt-2 leading-relaxed text-ink/65">{p.text}</p>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* 3. Why partner */}
      <section className="bg-forest-700 py-16 text-white sm:py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1fr_1.3fr] lg:px-8">
          <SectionHeading eyebrow="Why partner" title="Good for children," highlight="good for sites" text="A worksite centre protects children and gives parents peace of mind — which shows up in safety and retention." align="left" light />
          <ul className="grid gap-4 sm:grid-cols-2">
            {partnerBenefits.map((b, i) => (
              <Reveal as="li" key={b.title} delay={i * 0.06} className="rounded-3xl bg-white/10 p-6 backdrop-blur-sm">
                <Icon name={b.icon} className="h-7 w-7 text-sun" />
                <h3 className="mt-4 font-semibold">{b.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-white/70">{b.text}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* 4. Process */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <SectionHeading eyebrow="The process" title="From first call to" highlight="first child" className="mb-12" />
        <StepList steps={partnerSteps} />
      </section>

      {/* 5. Current supporters */}
      <div className="bg-plum-50/60"><Supporters /></div>

      {/* 6. Enquiry form */}
      <section id="enquire" className="mx-auto max-w-4xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <SectionHeading eyebrow="Enquire" title="Let's talk about" highlight="your site" text="Tell us a little about your organisation and we'll get back within 2 working days." />
        <Reveal className="mt-10 rounded-[2rem] border border-plum-100 bg-white p-6 shadow-xl shadow-plum-900/5 sm:p-10">
          {form.status === "done" ? (
            <SuccessMessage title="Enquiry sent" text="Thank you. Our partnerships team will contact you within 2 working days." onReset={form.reset} resetLabel="Send another enquiry" />
          ) : (
            <form onSubmit={form.handleSubmit(fakeSend)} noValidate className="grid gap-5 sm:grid-cols-2">
              <Field label="Organisation" {...form.bind("org")} autoComplete="organization" />
              <Field label="Partnership type" as="select" options={types} {...form.bind("type")} />
              <Field label="Your name" {...form.bind("name")} autoComplete="name" />
              <Field label="Work email" type="email" {...form.bind("email")} autoComplete="email" />
              <Field label="Phone" type="tel" {...form.bind("phone")} autoComplete="tel" className="sm:col-span-2" />
              <Field label="Tell us about your site or goals (optional)" as="textarea" className="sm:col-span-2" {...form.bind("message")} />
              <Button type="submit" className="sm:col-span-2" disabled={form.status === "sending"}>{form.status === "sending" ? "Sending…" : "Send enquiry"}</Button>
            </form>
          )}
        </Reveal>
      </section>
    </>
  );
}

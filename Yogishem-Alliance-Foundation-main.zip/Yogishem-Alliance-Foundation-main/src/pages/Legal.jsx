import usePageTitle from "../hooks/usePageTitle.js";
import PageHero from "../components/ui/PageHero.jsx";

// Placeholder legal text — replace with content reviewed by your legal advisor.
const content = {
  privacy: {
    title: "Privacy Policy",
    sections: [
      ["What we collect", "When you donate, volunteer or contact us, we collect your name, email, phone number and, if you choose, your PAN for tax receipts."],
      ["How we use it", "We use your information only to process donations, issue receipts, respond to you and send updates you've asked for."],
      ["Children's privacy", "We never publish photos of children without written consent from their parents or guardians."],
      ["Your choices", "You can unsubscribe from emails at any time or ask us to delete your data by writing to us."],
    ],
  },
  terms: {
    title: "Terms & Conditions",
    sections: [
      ["Use of this website", "Content on this website is provided for information about Yogishem Alliance Foundation and its programmes."],
      ["Donations", "Donations are voluntary and non-refundable except in cases of processing errors, which we will correct on request."],
      ["Intellectual property", "Text, photos and logos on this site belong to Yogishem Alliance Foundation unless otherwise credited."],
    ],
  },
};

export default function Legal({ page }) {
  const c = content[page];
  usePageTitle(c.title);
  return (
    <>
      <PageHero crumb={c.title} title={c.title} text="Last updated: September 2026" />
      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        {c.sections.map(([h, p]) => (
          <div key={h} className="mb-8">
            <h2 className="font-serif text-2xl font-bold text-ink">{h}</h2>
            <p className="mt-2 leading-relaxed text-ink/75">{p}</p>
          </div>
        ))}
      </section>
    </>
  );
}

import { useEffect, useState } from "react";
import { m, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Play, Camera } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Img from "../components/ui/Img.jsx";
import Button from "../components/ui/Button.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";
import { img } from "../data/images.js";
import { galleryCategories, galleryItems } from "../data/home.js";

function Lightbox({ items, index, onClose, onMove }) {
  useEffect(() => {
    const key = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onMove(1);
      if (e.key === "ArrowLeft") onMove(-1);
    };
    document.addEventListener("keydown", key);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", key);
      document.body.style.overflow = "";
    };
  }, [onClose, onMove]);

  const item = items[index];
  return (
    <m.div role="dialog" aria-modal="true" aria-label={item.caption} className="fixed inset-0 z-[60] flex items-center justify-center bg-ink/90 p-4 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <button type="button" aria-label="Close" onClick={onClose} className="absolute right-4 top-4 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20"><X /></button>
      <button type="button" aria-label="Previous" onClick={(e) => { e.stopPropagation(); onMove(-1); }} className="absolute left-3 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20 sm:left-6"><ChevronLeft /></button>
      <m.figure key={item.id} initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="max-h-full max-w-5xl" onClick={(e) => e.stopPropagation()}>
        <Img src={item.src} alt={item.caption} eager className="max-h-[78vh] w-auto rounded-2xl object-contain" />
        <figcaption className="mt-3 text-center text-white/85">{item.caption} <span className="text-white/50">· {index + 1}/{items.length}</span></figcaption>
      </m.figure>
      <button type="button" aria-label="Next" onClick={(e) => { e.stopPropagation(); onMove(1); }} className="absolute right-3 grid h-11 w-11 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20 sm:right-6"><ChevronRight /></button>
    </m.div>
  );
}

export default function Gallery() {
  usePageTitle("Gallery");
  const [cat, setCat] = useState("All");
  const [open, setOpen] = useState(null);
  const items = cat === "All" ? galleryItems : galleryItems.filter((g) => g.cat === cat);
  const move = (d) => setOpen((i) => (i + d + items.length) % items.length);

  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Gallery" title="Moments of" highlight="joy and learning" text="Snapshots from our centres, celebrations, health camps and community days." image={img.kidsSmiling} />

      {/* 2. Filterable masonry grid */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <div role="tablist" aria-label="Filter photos" className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 [scrollbar-width:none] sm:justify-center">
          {galleryCategories.map((c) => (
            <button key={c} role="tab" aria-selected={cat === c} onClick={() => setCat(c)} className={`relative shrink-0 rounded-full px-5 py-2.5 text-sm font-medium transition-colors ${cat === c ? "text-white" : "bg-plum-50 text-ink/70 hover:text-plum-700"}`}>
              {cat === c && <m.span layoutId="gallery-page-chip" className="absolute inset-0 rounded-full bg-plum-700" transition={{ type: "spring", stiffness: 400, damping: 32 }} />}
              <span className="relative">{c}</span>
            </button>
          ))}
        </div>
        <m.ul layout className="mt-10 columns-2 gap-4 md:columns-3 lg:columns-4 [&>li]:mb-4">
          <AnimatePresence mode="popLayout">
            {items.map((g, i) => (
              <m.li key={g.id} layout initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.94 }} transition={{ duration: 0.3 }} className="break-inside-avoid">
                <button type="button" onClick={() => setOpen(i)} className="group relative block w-full overflow-hidden rounded-3xl text-left">
                  <Img src={g.src} alt={g.caption} className={`w-full object-cover transition-transform duration-700 group-hover:scale-105 ${i % 3 === 0 ? "aspect-[3/4]" : i % 3 === 1 ? "aspect-square" : "aspect-[4/3]"}`} />
                  <span className="absolute inset-0 flex items-end bg-gradient-to-t from-plum-900/80 via-transparent to-transparent p-4 opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
                    <span className="text-sm font-medium text-white">{g.caption}</span>
                  </span>
                </button>
              </m.li>
            ))}
          </AnimatePresence>
        </m.ul>
      </section>

      {/* 3. Featured story / video */}
      <section className="bg-plum-900 py-16 text-white sm:py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 sm:px-6 lg:grid-cols-[1.3fr_1fr] lg:px-8">
          <Reveal className="group relative overflow-hidden rounded-[2rem]">
            <Img src={img.classroom} alt="" className="aspect-video w-full object-cover" />
            <a href="https://youtube.com" target="_blank" rel="noreferrer" aria-label="Watch our story on YouTube" className="absolute inset-0 grid place-items-center bg-ink/30 transition-colors group-hover:bg-ink/20">
              <span className="grid h-20 w-20 place-items-center rounded-full bg-white text-plum-700 shadow-2xl transition-transform group-hover:scale-110">
                <Play className="ml-1 h-8 w-8 fill-current" />
              </span>
            </a>
          </Reveal>
          <Reveal delay={0.1}>
            <SectionHeading eyebrow="Watch" title="A day in" highlight="3 minutes" text="Follow Meena, age 4, from her morning milk to her afternoon drawing — and meet the caretakers who make it happen." align="left" light />
            <Button href="https://youtube.com" variant="white" arrow className="mt-8" target="_blank" rel="noreferrer">Watch on YouTube</Button>
          </Reveal>
        </div>
      </section>

      {/* 4. Numbers strip */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <ul className="grid grid-cols-2 gap-6 md:grid-cols-4">
          {[["500+", "Photos captured"], ["40+", "Events held"], ["12", "Health camps"], ["100+", "Smiling children"]].map(([v, l], i) => (
            <Reveal as="li" key={l} delay={i * 0.06} className="rounded-3xl bg-plum-50 p-6 text-center">
              <p className="font-serif text-4xl font-bold text-plum-700">{v}</p>
              <p className="mt-1 text-sm text-ink/65">{l}</p>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* 5. Share photos */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8">
        <Reveal className="flex flex-col items-start gap-6 rounded-[2rem] border-2 border-dashed border-plum-200 p-8 sm:flex-row sm:items-center sm:p-10">
          <span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-plum-100"><Camera className="h-8 w-8 text-plum-700" /></span>
          <div className="flex-1">
            <h2 className="font-serif text-2xl font-bold text-ink">Volunteered or attended an event?</h2>
            <p className="mt-1 text-ink/65">Share your photos with us and they may be featured here (with permission from parents).</p>
          </div>
          <Button to="/contact" variant="outline" arrow>Share photos</Button>
        </Reveal>
      </section>

      <CTABanner />

      <AnimatePresence>{open !== null && <Lightbox items={items} index={open} onClose={() => setOpen(null)} onMove={move} />}</AnimatePresence>
    </>
  );
}

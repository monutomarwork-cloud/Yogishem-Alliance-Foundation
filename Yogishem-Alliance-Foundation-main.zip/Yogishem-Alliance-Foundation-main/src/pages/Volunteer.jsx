import { Quote } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import useForm, { required, email, phone, fakeSend } from "../hooks/useForm.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Icon from "../components/ui/Icon.jsx";
import Img from "../components/ui/Img.jsx";
import Button from "../components/ui/Button.jsx";
import Field from "../components/ui/Field.jsx";
import StepList from "../components/ui/StepList.jsx";
import FAQ from "../components/ui/FAQ.jsx";
import SuccessMessage from "../components/ui/SuccessMessage.jsx";
import { img } from "../data/images.js";
import { volunteerRoles, volunteerSteps, testimonials } from "../data/pages.js";
import { faqs } from "../data/faqs.js";

const interests = ["Teach & read", "Art & music", "Health camps", "Skills from home", "Not sure yet"];

export default function Volunteer() {
  usePageTitle("Volunteer");
  const form = useForm(
    { name: "", email: "", phone: "", city: "", interest: interests[0], message: "" },
    { name: required("name"), email, phone, city: required("city") }
  );

  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Volunteer" title="Give a few hours." highlight="Change a childhood." text="Join our weekend sessions, health camps and drives. No experience needed — just patience, warmth and a little time." image={img.volunteers}>
        <Button href="#apply" variant="white" arrow>Apply to volunteer</Button>
      </PageHero>

      {/* 2. Ways to help */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <SectionHeading eyebrow="Ways to help" title="Find the role that" highlight="fits you" />
        <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {volunteerRoles.map((r, i) => (
            <Reveal as="li" key={r.title} delay={i * 0.06} className="flex flex-col rounded-3xl border border-plum-100 bg-white p-7 transition-shadow hover:shadow-xl hover:shadow-plum-900/5">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-plum-50"><Icon name={r.icon} className="h-6 w-6 text-plum-700" /></span>
              <h3 className="mt-5 text-lg font-semibold text-ink">{r.title}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-ink/65">{r.text}</p>
              <span className="mt-5 w-fit rounded-full bg-forest-600/10 px-3 py-1 text-xs font-semibold text-forest-700">{r.time}</span>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* 3. Process */}
      <section className="bg-plum-900 py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="How it works" title="From sign-up to" highlight="first session" light className="mb-12" />
          <StepList steps={volunteerSteps} light />
        </div>
      </section>

      {/* 4. Testimonials */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <SectionHeading eyebrow="In their words" title="What volunteers" highlight="say" />
        <ul className="mt-12 grid gap-5 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal as="li" key={t.name} delay={i * 0.08} className={`rounded-3xl p-8 ${i === 1 ? "bg-plum-700 text-white" : "bg-plum-50"}`}>
              <Quote className={`h-8 w-8 ${i === 1 ? "text-sun" : "text-plum-500"}`} />
              <p className={`mt-4 font-serif text-lg leading-relaxed ${i === 1 ? "text-white" : "text-ink"}`}>{t.quote}</p>
              <p className="mt-6 font-semibold">{t.name}</p>
              <p className={`text-sm ${i === 1 ? "text-white/70" : "text-ink/60"}`}>{t.role}</p>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* 5. Application form */}
      <section id="apply" className="bg-gradient-to-b from-plum-50 to-white py-16 sm:py-24">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-[1fr_1.3fr] lg:px-8">
          <div>
            <SectionHeading eyebrow="Apply" title="Ready to" highlight="join us?" text="Fill in this short form and our volunteer coordinator will call you within a week." align="left" />
            <Reveal className="mt-8 hidden overflow-hidden rounded-3xl lg:block">
              <Img src={img.handsTogether} alt="" className="aspect-[4/3] w-full object-cover" />
            </Reveal>
          </div>
          <Reveal className="rounded-[2rem] bg-white p-6 shadow-xl shadow-plum-900/5 sm:p-10">
            {form.status === "done" ? (
              <SuccessMessage title="Application sent" text="Thank you! Our coordinator will call you within a week to plan your first session." onReset={form.reset} resetLabel="Submit another application" />
            ) : (
              <form onSubmit={form.handleSubmit(fakeSend)} noValidate className="grid gap-5 sm:grid-cols-2">
                <Field label="Full name" {...form.bind("name")} autoComplete="name" />
                <Field label="Email" type="email" {...form.bind("email")} autoComplete="email" />
                <Field label="Phone" type="tel" {...form.bind("phone")} autoComplete="tel" />
                <Field label="City" {...form.bind("city")} />
                <Field label="I'd like to help with" as="select" options={interests} className="sm:col-span-2" {...form.bind("interest")} />
                <Field label="Anything else? (optional)" as="textarea" className="sm:col-span-2" {...form.bind("message")} placeholder="Your skills, availability, languages…" />
                <Button type="submit" className="sm:col-span-2" disabled={form.status === "sending"}>{form.status === "sending" ? "Sending…" : "Send application"}</Button>
              </form>
            )}
          </Reveal>
        </div>
      </section>

      {/* 6. FAQ */}
      <FAQ items={faqs.volunteer} />
    </>
  );
}

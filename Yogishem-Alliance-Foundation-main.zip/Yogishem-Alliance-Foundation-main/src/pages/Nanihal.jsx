import { Heart, Clock } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import useCountUp from "../hooks/useCountUp.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Img from "../components/ui/Img.jsx";
import Icon from "../components/ui/Icon.jsx";
import Button from "../components/ui/Button.jsx";
import FAQ from "../components/ui/FAQ.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";
import { img } from "../data/images.js";
import { pillars, dailySchedule } from "../data/pages.js";
import { faqs } from "../data/faqs.js";

function Stat({ end, suffix = "", label }) {
  const [ref, v] = useCountUp(end);
  return (
    <div className="text-center">
      <p ref={ref} className="font-serif text-5xl font-bold text-plum-700 sm:text-6xl">{v}{suffix}</p>
      <p className="mt-2 text-sm text-ink/65">{label}</p>
    </div>
  );
}

export default function Nanihal() {
  usePageTitle("Nanihal");
  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Nanihal" title="Nanihal — a second home for" highlight="little ones." text="Our flagship initiative runs safe, joyful day-care and early learning centres right at construction sites, for children aged 2 to 8." image={img.localCentre}>
        <div className="flex flex-wrap gap-3">
          <Button to="/donate" variant="white" icon={Heart}>Sponsor a child</Button>
          <Button to="/partner" className="bg-white/10! shadow-none hover:bg-white/20!" arrow>Host a centre</Button>
        </div>
      </PageHero>

      {/* 2. What is Nanihal */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr] lg:gap-20">
          <Reveal>
            <SectionHeading eyebrow="The idea" title="A centre where" highlight="parents work" align="left" />
            <p className="mt-6 text-lg leading-relaxed text-ink/75">"Nanihal" means a grandmother's home — the warmest, safest place a child knows. That's what we try to build at every site.</p>
            <p className="mt-4 leading-relaxed text-ink/70">Instead of spending the day beside heavy machinery, children come to a clean, supervised centre a short walk from where their parents work. They eat, play, learn and rest — and go home happy.</p>
          </Reveal>
          <Reveal delay={0.1} className="grid grid-cols-2 gap-4">
            <Img src={img.childReading} alt="" className="aspect-[3/4] w-full rounded-3xl object-cover" />
            <Img src={img.kidsPencils} alt="" className="mt-10 aspect-[3/4] w-full rounded-3xl object-cover" />
          </Reveal>
        </div>
      </section>

      {/* 3. Pillars (bento) */}
      <section className="bg-plum-50/60 py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="What we provide" title="Six pillars of" highlight="care" />
          <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {pillars.map((p, i) => (
              <Reveal as="li" key={p.title} delay={(i % 3) * 0.06} className={`rounded-3xl p-7 ${i === 0 ? "bg-plum-700 text-white" : "bg-white"}`}>
                <span className={`grid h-12 w-12 place-items-center rounded-2xl ${i === 0 ? "bg-white/15" : "bg-plum-50"}`}>
                  <Icon name={p.icon} className={`h-6 w-6 ${i === 0 ? "text-sun" : "text-plum-700"}`} />
                </span>
                <h3 className={`mt-5 font-semibold ${i === 0 ? "text-lg" : "text-lg text-ink"}`}>{p.title}</h3>
                <p className={`mt-2 leading-relaxed ${i === 0 ? "text-white/80" : "text-sm text-ink/65"}`}>{p.text}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* 4. A day at Nanihal */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.3fr] lg:gap-20">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <SectionHeading eyebrow="Daily routine" title="A day at" highlight="Nanihal" text="A predictable routine helps young children feel safe. Here's what a typical day looks like." align="left" />
            <Reveal className="mt-8 hidden lg:block">
              <Img src={img.childPlaying} alt="" className="aspect-[4/3] w-full rounded-3xl object-cover" />
            </Reveal>
          </div>
          <ol className="space-y-4">
            {dailySchedule.map((d, i) => (
              <Reveal as="li" key={d.time} delay={i * 0.04} className="flex gap-5 rounded-3xl border border-plum-100 bg-white p-5 sm:p-6">
                <span className="flex h-fit shrink-0 items-center gap-1.5 rounded-xl bg-plum-50 px-3 py-2 text-sm font-semibold text-plum-700">
                  <Clock className="h-4 w-4" /> {d.time}
                </span>
                <div>
                  <h3 className="font-semibold text-ink">{d.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-ink/65">{d.text}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* 5. Impact numbers */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="grid grid-cols-2 gap-8 rounded-[2rem] bg-gradient-to-br from-plum-50 to-amber-50 px-6 py-12 sm:px-10 md:grid-cols-4">
          <Stat end={100} suffix="+" label="Children every day" />
          <Stat end={6} label="Days a week" />
          <Stat end={3} label="Meals & snacks daily" />
          <Stat end={12} label="Health camps a year" />
        </Reveal>
      </section>

      {/* 6. FAQ */}
      <FAQ items={faqs.nanihal} />

      <CTABanner title="Help us open the next centre" text="Every new Nanihal centre gives 30–40 more children a safe place to grow." cta="Partner with us" to="/partner" />
    </>
  );
}

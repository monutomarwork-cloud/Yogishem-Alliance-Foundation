import { useState } from "react";
import { Link } from "react-router-dom";
import { m } from "framer-motion";
import { Heart, ShieldCheck, Receipt, BadgeCheck } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import useForm, { required, email, phone, fakeSend } from "../hooks/useForm.js";
import PageHero from "../components/ui/PageHero.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Icon from "../components/ui/Icon.jsx";
import Button from "../components/ui/Button.jsx";
import Field from "../components/ui/Field.jsx";
import FAQ from "../components/ui/FAQ.jsx";
import SuccessMessage from "../components/ui/SuccessMessage.jsx";
import { img } from "../data/images.js";
import { donationTiers, fundAllocation, otherWays } from "../data/pages.js";
import { faqs } from "../data/faqs.js";

const inr = (n) => "₹" + Number(n).toLocaleString("en-IN");

function DonationForm() {
  const [freq, setFreq] = useState("Monthly");
  const [amount, setAmount] = useState(1000);
  const [custom, setCustom] = useState("");
  const value = custom ? Number(custom) : amount;
  const tier = [...donationTiers].reverse().find((t) => value >= t.amount);

  const form = useForm({ name: "", email: "", phone: "", pan: "" }, {
    name: required("name"),
    email,
    phone,
    pan: (v) => (!v || /^[A-Z]{5}[0-9]{4}[A-Z]$/i.test(v) ? "" : "Enter a valid 10-character PAN, like ABCDE1234F."),
  });
  const [amountError, setAmountError] = useState("");

  const submit = (e) => {
    if (!value || value < 100) {
      e.preventDefault();
      return setAmountError("Enter an amount of ₹100 or more.");
    }
    // TODO: open your payment gateway (Razorpay / PayU / Stripe) here with `value` and `freq`.
    return form.handleSubmit(fakeSend)(e);
  };

  if (form.status === "done") {
    return <SuccessMessage title="Thank you for your gift" text={`We've received your ${freq.toLowerCase()} donation of ${inr(value)}. A receipt will be sent to your email.`} onReset={form.reset} resetLabel="Make another donation" />;
  }

  return (
    <form onSubmit={submit} noValidate>
      <div className="grid grid-cols-2 rounded-2xl bg-plum-50 p-1" role="radiogroup" aria-label="Donation frequency">
        {["One-time", "Monthly"].map((f) => (
          <button type="button" key={f} role="radio" aria-checked={freq === f} onClick={() => setFreq(f)} className="relative rounded-xl py-3 text-sm font-semibold">
            {freq === f && <m.span layoutId="freq" className="absolute inset-0 rounded-xl bg-white shadow" transition={{ type: "spring", stiffness: 400, damping: 32 }} />}
            <span className={`relative ${freq === f ? "text-plum-700" : "text-ink/60"}`}>{f}</span>
          </button>
        ))}
      </div>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-ink/80">Choose an amount</legend>
        <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {donationTiers.map((t) => (
            <button type="button" key={t.amount} aria-pressed={!custom && amount === t.amount} onClick={() => { setAmount(t.amount); setCustom(""); setAmountError(""); }} className={`rounded-xl border-2 py-3 font-semibold transition-colors ${!custom && amount === t.amount ? "border-plum-700 bg-plum-700 text-white" : "border-plum-100 text-ink hover:border-plum-500"}`}>
              {inr(t.amount)}
            </button>
          ))}
        </div>
        <label className="mt-3 block">
          <span className="sr-only">Custom amount</span>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-semibold text-ink/50">₹</span>
            <input inputMode="numeric" value={custom} onChange={(e) => { setCustom(e.target.value.replace(/\D/g, "")); setAmountError(""); }} placeholder="Other amount" className={`w-full rounded-xl border bg-white py-3 pl-9 pr-4 outline-none focus:border-plum-500 focus:ring-4 focus:ring-plum-100 ${amountError ? "border-red-400" : "border-plum-100"}`} />
          </div>
          {amountError && <span className="mt-1 block text-xs text-red-600">{amountError}</span>}
        </label>
      </fieldset>

      <m.p key={tier?.amount} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="mt-5 flex gap-3 rounded-2xl bg-forest-600/10 p-4 text-sm text-forest-800">
        <Heart className="mt-0.5 h-4 w-4 shrink-0 fill-current" />
        <span>{tier ? <><strong>{inr(value)}</strong>{freq === "Monthly" && " a month"} can provide: {tier.impact.toLowerCase()}.</> : "Every rupee goes towards meals, learning and care for the children."}</span>
      </m.p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Full name" {...form.bind("name")} autoComplete="name" />
        <Field label="Email" type="email" {...form.bind("email")} autoComplete="email" />
        <Field label="Phone" type="tel" {...form.bind("phone")} autoComplete="tel" />
        <Field label="PAN (optional, for 80G receipt)" {...form.bind("pan")} />
      </div>
      <Button type="submit" icon={Heart} className="mt-6 w-full py-4 text-base" disabled={form.status === "sending"}>
        {form.status === "sending" ? "Processing…" : `Donate ${value ? inr(value) : ""}${freq === "Monthly" ? " / month" : ""}`}
      </Button>
      <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-ink/55"><ShieldCheck className="h-4 w-4" /> Secure payment · 80G tax benefit</p>
    </form>
  );
}

export default function Donate() {
  usePageTitle("Donate");
  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Donate" title="Your gift gives a child" highlight="a safer day." text="Meals, learning, health checkups and a safe space — for children of construction workers aged 2 to 8." image={img.childReading}>
        <Button href="#give" variant="white" icon={Heart}>Donate now</Button>
      </PageHero>

      {/* 2. Donation form + trust */}
      <section id="give" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.15fr] lg:gap-16">
          <div>
            <SectionHeading eyebrow="Give" title="Make a" highlight="donation" text="Monthly gifts help us plan meals, staff and supplies with confidence." align="left" />
            <ul className="mt-8 space-y-4">
              {[
                [ShieldCheck, "Safe & secure", "Payments are processed by a trusted, encrypted payment gateway."],
                [Receipt, "80G tax benefit", "Add your PAN to receive a tax-deductible receipt by email."],
                [BadgeCheck, "Registered non-profit", "We publish how every rupee is spent in our annual report."],
              ].map(([I, t, d]) => (
                <Reveal as="li" key={t} className="flex gap-4">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-plum-50"><I className="h-5 w-5 text-plum-700" /></span>
                  <div><h3 className="font-semibold text-ink">{t}</h3><p className="text-sm text-ink/65">{d}</p></div>
                </Reveal>
              ))}
            </ul>
          </div>
          <Reveal className="rounded-[2rem] border border-plum-100 bg-white p-6 shadow-2xl shadow-plum-900/10 sm:p-10">
            <DonationForm />
          </Reveal>
        </div>
      </section>

      {/* 3. What your gift does */}
      <section className="bg-plum-50/60 py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="Your impact" title="What your gift" highlight="makes possible" />
          <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {donationTiers.map((t, i) => (
              <Reveal as="li" key={t.amount} delay={i * 0.06} className={`rounded-3xl p-7 ${i === 1 ? "bg-plum-700 text-white" : "bg-white"}`}>
                <p className={`font-serif text-4xl font-bold ${i === 1 ? "text-white" : "text-plum-700"}`}>{inr(t.amount)}</p>
                <p className={`mt-3 leading-relaxed ${i === 1 ? "text-white/85" : "text-ink/70"}`}>{t.impact}</p>
                {i === 1 && <span className="mt-4 inline-block rounded-full bg-sun px-3 py-1 text-xs font-semibold text-ink">Most chosen</span>}
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* 4. Where the money goes */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          <SectionHeading eyebrow="Transparency" title="Where every" highlight="rupee goes" text="85% of every donation goes directly into programmes for the children." align="left" />
          <Reveal>
            <div className="flex h-5 overflow-hidden rounded-full" aria-hidden>
              {fundAllocation.map((f) => (
                <m.span key={f.label} className={f.color} initial={{ width: 0 }} whileInView={{ width: `${f.value}%` }} viewport={{ once: true }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }} />
              ))}
            </div>
            <ul className="mt-8 grid gap-4 sm:grid-cols-2">
              {fundAllocation.map((f) => (
                <li key={f.label} className="flex items-center gap-3 rounded-2xl border border-plum-100 p-4">
                  <span className={`h-4 w-4 shrink-0 rounded-full ${f.color}`} />
                  <span className="flex-1 text-sm text-ink/75">{f.label}</span>
                  <span className="font-serif text-xl font-bold text-ink">{f.value}%</span>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>

      {/* 5. Other ways to give */}
      <section className="bg-plum-900 py-16 text-white sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="More ways" title="Other ways to" highlight="give" light />
          <ul className="mt-12 grid gap-5 md:grid-cols-3">
            {otherWays.map((w, i) => (
              <Reveal as="li" key={w.title} delay={i * 0.08}>
                <Link to={w.to} className="group block h-full rounded-3xl bg-white/10 p-7 transition-colors hover:bg-white/15">
                  <Icon name={w.icon} className="h-8 w-8 text-sun" />
                  <h3 className="mt-5 font-serif text-2xl font-bold">{w.title}</h3>
                  <p className="mt-2 text-white/70">{w.text}</p>
                  <span className="mt-5 inline-block font-semibold text-plum-200 group-hover:text-white">Learn more →</span>
                </Link>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>

      {/* 6. FAQ */}
      <FAQ items={faqs.donate} />
    </>
  );
}

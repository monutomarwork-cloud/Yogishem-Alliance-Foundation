import { Link, useParams } from "react-router-dom";
import { m, useScroll, useSpring } from "framer-motion";
import { ArrowLeft, Clock, Share2 } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import Img from "../components/ui/Img.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";
import Newsletter from "../components/ui/Newsletter.jsx";
import { PostCard } from "../components/home/BlogPreview.jsx";
import { getPost, posts } from "../data/blog.js";
import NotFound from "./NotFound.jsx";

export default function BlogPost() {
  const { slug } = useParams();
  const post = getPost(slug);
  usePageTitle(post?.title || "Post not found");
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });

  if (!post) return <NotFound />;
  const related = posts.filter((p) => p.slug !== post.slug && p.category === post.category).concat(posts.filter((p) => p.slug !== post.slug)).filter((p, i, a) => a.indexOf(p) === i).slice(0, 3);

  const share = () => {
    if (navigator.share) navigator.share({ title: post.title, url: window.location.href }).catch(() => {});
    else navigator.clipboard?.writeText(window.location.href);
  };

  return (
    <>
      <m.div style={{ scaleX: progress }} className="fixed inset-x-0 top-0 z-50 h-1 origin-left bg-plum-700" aria-hidden />

      <article>
        <header className="mx-auto max-w-3xl px-4 pt-12 sm:px-6 sm:pt-16">
          <Link to="/blog" className="inline-flex items-center gap-2 text-sm font-medium text-plum-700 hover:underline"><ArrowLeft className="h-4 w-4" /> All posts</Link>
          <p className="mt-6 flex flex-wrap items-center gap-3 text-sm text-ink/60">
            <span className="rounded-full bg-plum-50 px-3 py-1 font-medium text-plum-700">{post.category}</span>
            <span>{post.date}</span>
            <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {post.readTime}</span>
          </p>
          <h1 className="mt-4 font-serif text-4xl font-bold leading-tight text-ink sm:text-5xl">{post.title}</h1>
          <p className="mt-4 text-xl leading-relaxed text-ink/70">{post.excerpt}</p>
          <div className="mt-6 flex items-center justify-between border-y border-plum-100 py-4">
            <div className="flex items-center gap-3">
              <img src="/images/yaf-logo.png" alt="" className="h-10 w-10 rounded-full" />
              <span className="text-sm font-medium text-ink">{post.author}</span>
            </div>
            <button type="button" onClick={share} className="inline-flex items-center gap-2 rounded-full bg-plum-50 px-4 py-2 text-sm font-medium text-plum-700 hover:bg-plum-100"><Share2 className="h-4 w-4" /> Share</button>
          </div>
        </header>

        <div className="mx-auto mt-10 max-w-5xl px-4 sm:px-6">
          <Img src={post.image} alt="" eager className="aspect-[16/8] w-full rounded-[2rem] object-cover" />
        </div>

        <div className="mx-auto max-w-2xl px-4 py-12 text-lg leading-[1.8] text-ink/80 sm:px-6 sm:py-16">
          {post.body.map((b, i) =>
            b.type === "h2" ? (
              <h2 key={i} className="mb-4 mt-10 font-serif text-2xl font-bold text-ink sm:text-3xl">{b.text}</h2>
            ) : b.type === "quote" ? (
              <blockquote key={i} className="my-8 border-l-4 border-plum-700 pl-6 font-serif text-2xl italic leading-snug text-plum-800">{b.text}</blockquote>
            ) : (
              <p key={i} className="mb-5">{b.text}</p>
            )
          )}
        </div>
      </article>

      <section className="bg-plum-50/60 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Keep" highlight="reading" align="left" />
          <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((p, i) => <Reveal key={p.slug} delay={i * 0.06} as="article"><PostCard p={p} /></Reveal>)}
          </div>
        </div>
      </section>

      <Newsletter />
      <CTABanner title="Moved by this story?" text="Sponsor a child's meals, learning and care at Nanihal." cta="Donate Now" to="/donate" />
    </>
  );
}

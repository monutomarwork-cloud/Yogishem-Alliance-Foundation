import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { m, AnimatePresence } from "framer-motion";
import { Search, Clock } from "lucide-react";
import usePageTitle from "../hooks/usePageTitle.js";
import PageHero from "../components/ui/PageHero.jsx";
import Reveal from "../components/ui/Reveal.jsx";
import Img from "../components/ui/Img.jsx";
import Button from "../components/ui/Button.jsx";
import SectionHeading from "../components/ui/SectionHeading.jsx";
import CTABanner from "../components/ui/CTABanner.jsx";
import Newsletter from "../components/ui/Newsletter.jsx";
import { PostCard } from "../components/home/BlogPreview.jsx";
import { img } from "../data/images.js";
import { posts, blogCategories } from "../data/blog.js";

export default function Blog() {
  usePageTitle("Blog");
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const featured = posts.find((p) => p.featured) || posts[0];

  const list = useMemo(
    () =>
      posts.filter(
        (p) => p !== featured && (cat === "All" || p.category === cat) && (p.title + p.excerpt).toLowerCase().includes(q.toLowerCase())
      ),
    [cat, q, featured]
  );

  return (
    <>
      {/* 1. Hero */}
      <PageHero crumb="Blog" title="Stories, updates &" highlight="insights" text="News from our centres, lessons from the field and ideas on early childhood care." image={img.books} />

      {/* 2. Featured post */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <Reveal>
          <Link to={`/blog/${featured.slug}`} className="group grid overflow-hidden rounded-[2rem] bg-plum-50 lg:grid-cols-2">
            <div className="overflow-hidden">
              <Img src={featured.image} alt="" className="aspect-[16/10] h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
            </div>
            <div className="flex flex-col justify-center p-8 sm:p-12">
              <span className="w-fit rounded-full bg-plum-700 px-3 py-1 text-xs font-semibold text-white">Featured</span>
              <h2 className="mt-4 font-serif text-3xl font-bold text-ink transition-colors group-hover:text-plum-700 sm:text-4xl">{featured.title}</h2>
              <p className="mt-3 text-lg leading-relaxed text-ink/70">{featured.excerpt}</p>
              <p className="mt-6 flex items-center gap-3 text-sm text-ink/60">
                <span>{featured.date}</span><span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {featured.readTime}</span>
              </p>
            </div>
          </Link>
        </Reveal>
      </section>

      {/* 3. Filters + search + grid */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="-mx-4 flex gap-2 overflow-x-auto px-4 [scrollbar-width:none] md:mx-0 md:px-0">
            {blogCategories.map((c) => (
              <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c} className={`shrink-0 rounded-full px-4 py-2 text-sm font-medium transition-colors ${cat === c ? "bg-plum-700 text-white" : "bg-plum-50 text-ink/70 hover:text-plum-700"}`}>{c}</button>
            ))}
          </div>
          <label className="relative block md:w-72">
            <span className="sr-only">Search posts</span>
            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search posts" className="w-full rounded-full border border-plum-100 bg-white py-2.5 pl-11 pr-4 outline-none focus:border-plum-500 focus:ring-4 focus:ring-plum-100" />
          </label>
        </div>
        <m.div layout className="mt-10 grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {list.map((p) => (
              <m.article key={p.slug} layout initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.96 }} transition={{ duration: 0.3 }}>
                <PostCard p={p} />
              </m.article>
            ))}
          </AnimatePresence>
        </m.div>
        {list.length === 0 && (
          <div className="mt-10 rounded-3xl bg-plum-50 p-10 text-center">
            <p className="font-semibold text-ink">No posts match "{q}"{cat !== "All" && ` in ${cat}`}.</p>
            <button className="mt-3 font-semibold text-plum-700 hover:underline" onClick={() => { setQ(""); setCat("All"); }}>Clear filters</button>
          </div>
        )}
      </section>

      {/* 4. Write for us */}
      <section className="bg-plum-900 py-16 text-white sm:py-20">
        <div className="mx-auto flex max-w-7xl flex-col items-start gap-6 px-4 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
          <SectionHeading eyebrow="Guest posts" title="Have a story to" highlight="share?" text="Volunteers, donors and partners — we'd love to publish your experience with Nanihal." align="left" light />
          <Button to="/contact" variant="white" arrow>Write for us</Button>
        </div>
      </section>

      {/* 5. Newsletter */}
      <Newsletter />

      <CTABanner title="Turn reading into action" text="Your support keeps these stories going — for 100+ children every day." cta="Donate Now" to="/donate" />
    </>
  );
}

import { lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { LazyMotion, domMax, MotionConfig } from "framer-motion";
import Layout from "./components/layout/Layout.jsx";
import Home from "./pages/Home.jsx";

// Inner pages are code-split: each loads only when visited.
const About = lazy(() => import("./pages/About.jsx"));
const Nanihal = lazy(() => import("./pages/Nanihal.jsx"));
const Gallery = lazy(() => import("./pages/Gallery.jsx"));
const Blog = lazy(() => import("./pages/Blog.jsx"));
const BlogPost = lazy(() => import("./pages/BlogPost.jsx"));
const Volunteer = lazy(() => import("./pages/Volunteer.jsx"));
const Partner = lazy(() => import("./pages/Partner.jsx"));
const Events = lazy(() => import("./pages/Events.jsx"));
const Contact = lazy(() => import("./pages/Contact.jsx"));
const Donate = lazy(() => import("./pages/Donate.jsx"));
const Legal = lazy(() => import("./pages/Legal.jsx"));
const NotFound = lazy(() => import("./pages/NotFound.jsx"));

export default function App() {
  return (
    // domMax adds layout animations (filters, tabs, nav underline) on top of domAnimation
    <LazyMotion features={domMax} strict>
      <MotionConfig reducedMotion="user">
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="about" element={<About />} />
            <Route path="nanihal" element={<Nanihal />} />
            <Route path="gallery" element={<Gallery />} />
            <Route path="blog" element={<Blog />} />
            <Route path="blog/:slug" element={<BlogPost />} />
            <Route path="volunteer" element={<Volunteer />} />
            <Route path="partner" element={<Partner />} />
            <Route path="events" element={<Events />} />
            <Route path="contact" element={<Contact />} />
            <Route path="donate" element={<Donate />} />
            <Route path="privacy" element={<Legal page="privacy" />} />
            <Route path="terms" element={<Legal page="terms" />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </MotionConfig>
    </LazyMotion>
  );
}

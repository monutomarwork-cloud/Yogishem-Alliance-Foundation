import { Link } from "react-router-dom";
import { MapPin, Phone, Mail } from "lucide-react";
import { contact, socials } from "../../data/site.js";
import SocialIcon from "../ui/SocialIcon.jsx";

const quickLinks = [
  { label: "Home", to: "/" },
  { label: "About YAF", to: "/about" },
  { label: "Nanihal", to: "/nanihal" },
  { label: "Gallery", to: "/gallery" },
  { label: "Blog", to: "/blog" },
  { label: "Contact Us", to: "/contact" },
];
const involved = [
  { label: "Volunteer", to: "/volunteer" },
  { label: "Partner with us", to: "/partner" },
  { label: "Events", to: "/events" },
  { label: "Donate", to: "/donate" },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-plum-800 text-white/80">
      <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-plum-700/60" aria-hidden />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:grid-cols-2 sm:px-6 lg:grid-cols-[1.5fr_1fr_1fr_1.3fr_1fr] lg:px-8 lg:py-16">
        <div>
          <Link to="/" className="flex items-center gap-3">
            <img src="/images/yaf-logo.png" alt="" loading="lazy" className="h-16 w-16 rounded-full border-2 border-white/80 bg-white" />
            <span className="leading-tight">
              <span className="block font-serif text-lg font-bold text-white">Yogishem Alliance Foundation</span>
              <span className="block text-sm text-white/60">Nurturing Futures, Transforming Lives</span>
            </span>
          </Link>
          <p className="mt-5 max-w-xs text-sm leading-relaxed">
            Education, health and care for the children of construction workers — so every child gets a fair chance to learn, grow and dream.
          </p>
        </div>

        <nav aria-label="Quick links">
          <h3 className="font-semibold text-white">Quick Links</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {quickLinks.map((l) => <li key={l.to}><Link to={l.to} className="hover:text-white">{l.label}</Link></li>)}
          </ul>
        </nav>

        <nav aria-label="Get involved">
          <h3 className="font-semibold text-white">Get Involved</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {involved.map((l) => <li key={l.to}><Link to={l.to} className="hover:text-white">{l.label}</Link></li>)}
          </ul>
        </nav>

        <div>
          <h3 className="font-semibold text-white">Contact Us</h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex gap-3"><MapPin className="h-5 w-5 shrink-0 text-plum-200" /> {contact.address}</li>
            <li className="flex gap-3"><Phone className="h-5 w-5 shrink-0 text-plum-200" /><a href={contact.phoneHref} className="hover:text-white">{contact.phone}</a></li>
            <li className="flex gap-3"><Mail className="h-5 w-5 shrink-0 text-plum-200" /><a href={`mailto:${contact.email}`} className="break-all hover:text-white">{contact.email}</a></li>
          </ul>
        </div>

        <div>
          <h3 className="font-semibold text-white">Follow Us</h3>
          <ul className="mt-4 flex flex-wrap gap-2">
            {socials.map((s) => (
              <li key={s.name}>
                <a href={s.href} target="_blank" rel="noreferrer" aria-label={s.name} className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 text-white transition-colors hover:bg-white hover:text-plum-800">
                  <SocialIcon name={s.icon} />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="relative border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-5 text-xs text-white/55 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p>© {new Date().getFullYear()} Yogishem Alliance Foundation. All Rights Reserved.</p>
          <p className="flex gap-4">
            <Link to="/privacy" className="hover:text-white">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-white">Terms &amp; Conditions</Link>
          </p>
        </div>
      </div>
    </footer>
  );
}

import { Smile } from "lucide-react";
import Reveal from "../ui/Reveal.jsx";
import Button from "../ui/Button.jsx";
import Img from "../ui/Img.jsx";
import { img } from "../../data/images.js";

export default function ChildhoodCTA() {
  return (
    <section className="relative isolate overflow-hidden">
      <Img src={img.kidsSmiling} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-ink/80 via-ink/70 to-plum-900/85" />
      <Reveal className="mx-auto max-w-3xl px-4 py-20 text-center text-white sm:py-28">
        <h2 className="font-serif text-3xl font-bold leading-tight sm:text-5xl">
          Every Child Deserves<br />
          a Good Childhood <Smile className="inline h-8 w-8 -translate-y-1 text-sun sm:h-11 sm:w-11" strokeWidth={2.2} aria-hidden />
        </h2>
        <p className="mx-auto mt-5 max-w-xl text-lg text-white/80">We make sure children have a safe, healthy and happy environment for learning.</p>
        <Button to="/donate" className="mt-8 px-10 py-4 text-base">Donate Now</Button>
      </Reveal>
    </section>
  );
}

import Reveal from "../ui/Reveal.jsx";
import SectionHeading from "../ui/SectionHeading.jsx";
import Icon from "../ui/Icon.jsx";
import { supportItems } from "../../data/home.js";

const tints = {
  amber: "bg-amber-50 border-amber-100 [--icon:#c47a0a]",
  green: "bg-emerald-50 border-emerald-100 [--icon:#1f6b4a]",
  pink: "bg-plum-50 border-plum-100 [--icon:#86247b]",
  blue: "bg-sky-50 border-sky-100 [--icon:#1e6a9a]",
};

export default function Support() {
  return (
    <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8">
      <SectionHeading
        eyebrow="Our support"
        title="Empowering"
        highlight="Underprivileged Children"
        text="Offers not just education but also emphasizes health, hygiene, and engaging activities."
      />
      <ul className="mt-12 grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
        {supportItems.map((s, i) => (
          <Reveal as="li" key={s.title} delay={(i % 4) * 0.06} className={`group rounded-3xl border p-5 text-center transition-shadow hover:shadow-lg hover:shadow-plum-900/5 sm:p-7 ${tints[s.tint]}`}>
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-white shadow-sm transition-transform group-hover:-translate-y-1 sm:h-16 sm:w-16">
              <Icon name={s.icon} className="h-7 w-7 text-[var(--icon)] sm:h-8 sm:w-8" strokeWidth={1.7} />
            </span>
            <h3 className="mt-4 text-sm font-semibold text-ink sm:text-base">{s.title}</h3>
            <p className="mt-1 text-xs leading-relaxed text-ink/60 sm:text-sm">{s.text}</p>
          </Reveal>
        ))}
      </ul>
    </section>
  );
}

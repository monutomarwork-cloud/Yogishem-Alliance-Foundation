import { useRef, useState } from "react";
import { m, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import SectionHeading from "../ui/SectionHeading.jsx";
import Img from "../ui/Img.jsx";
import Button from "../ui/Button.jsx";
import { galleryCategories, galleryItems } from "../../data/home.js";

export default function GalleryStrip() {
  const [cat, setCat] = useState("All");
  const track = useRef(null);
  const items = cat === "All" ? galleryItems : galleryItems.filter((g) => g.cat === cat);

  const scroll = (dir) => {
    const el = track.current;
    if (el) el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: "smooth" });
  };

  return (
    <section className="bg-gradient-to-b from-plum-50 to-white py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading eyebrow="Our moments" title="Nanihal Gallery" text="A glimpse into the learning, joy and daily activities of the children." align="left" />
          <div role="tablist" aria-label="Filter photos" className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none] lg:mx-0 lg:px-0">
            {galleryCategories.map((c) => (
              <button
                key={c}
                role="tab"
                aria-selected={cat === c}
                onClick={() => setCat(c)}
                className={`relative shrink-0 rounded-full px-4 py-2 text-sm font-medium transition-colors ${cat === c ? "text-white" : "bg-white text-ink/70 ring-1 ring-plum-100 hover:text-plum-700"}`}
              >
                {cat === c && <m.span layoutId="gallery-chip" className="absolute inset-0 rounded-full bg-plum-700" transition={{ type: "spring", stiffness: 400, damping: 32 }} />}
                <span className="relative">{c}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="relative mx-auto mt-10 max-w-[1400px]">
        <button type="button" onClick={() => scroll(-1)} aria-label="Previous photos" className="absolute left-2 top-1/2 z-10 hidden h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white shadow-lg sm:grid">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <ul ref={track} className="flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-px-4 px-4 pb-4 [scrollbar-width:none] sm:px-16">
          <AnimatePresence mode="popLayout" initial={false}>
            {items.map((g) => (
              <m.li
                key={g.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="group relative w-[72%] shrink-0 snap-start overflow-hidden rounded-3xl sm:w-[40%] lg:w-[23%]"
              >
                <Img src={g.src} alt={g.caption} className="aspect-[4/5] w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-plum-900/85 to-transparent p-4 pt-12">
                  <span className="text-xs font-medium text-plum-200">{g.cat}</span>
                  <p className="text-sm font-medium text-white">{g.caption}</p>
                </div>
              </m.li>
            ))}
          </AnimatePresence>
        </ul>
        <button type="button" onClick={() => scroll(1)} aria-label="Next photos" className="absolute right-2 top-1/2 z-10 hidden h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white shadow-lg sm:grid">
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div className="mt-6 text-center">
        <Button to="/gallery" variant="outline" arrow>View Full Gallery</Button>
      </div>
    </section>
  );
}

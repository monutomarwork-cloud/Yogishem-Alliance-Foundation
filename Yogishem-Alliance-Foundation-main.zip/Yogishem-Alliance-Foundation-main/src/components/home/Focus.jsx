import { Sun, Heart, Leaf } from "lucide-react";
import Reveal from "../ui/Reveal.jsx";
import Img from "../ui/Img.jsx";
import { img } from "../../data/images.js";

export default function Focus() {
  return (
    <section className="mt-16 bg-gradient-to-r from-plum-50 via-white to-amber-50/60 sm:mt-24">
      <div className="mx-auto grid max-w-7xl items-center gap-8 px-4 py-12 sm:px-6 md:grid-cols-[0.9fr_1.1fr] lg:gap-16 lg:px-8 lg:py-16">
        <Reveal className="relative mx-auto w-full max-w-md">
          <Heart className="absolute -left-2 top-4 h-8 w-8 rotate-[-15deg] text-plum-200" aria-hidden />
          <Leaf className="absolute -bottom-2 -left-4 h-12 w-12 text-forest-600/40" aria-hidden />
          <div className="overflow-hidden rounded-[2.5rem_2.5rem_2.5rem_0.75rem] border-8 border-white shadow-xl shadow-plum-900/10">
            <Img src={img.paintedHands} alt="A young child showing hands covered in colourful paint" className="aspect-[4/3] w-full object-cover" />
          </div>
        </Reveal>
        <Reveal delay={0.1} className="relative">
          <Sun className="absolute -top-4 right-0 h-12 w-12 text-sun sm:h-16 sm:w-16" strokeWidth={1.6} aria-hidden />
          <span className="inline-block rounded-full bg-plum-100 px-3 py-1 text-xs font-semibold text-plum-700 sm:text-sm">Our focus</span>
          <h2 className="mt-3 font-serif text-2xl font-semibold text-ink sm:text-3xl">Catering specifically to the age group of</h2>
          <p className="mt-1 font-serif text-6xl font-bold tracking-tight text-plum-700 sm:text-7xl lg:text-8xl">
            2 – 8 <span className="text-4xl sm:text-5xl lg:text-6xl">years.</span>
          </p>
          <p className="mt-4 max-w-md text-lg text-ink/70">Early childhood is the foundation for a brighter future — the years when care, food and play shape a lifetime.</p>
        </Reveal>
      </div>
    </section>
  );
}

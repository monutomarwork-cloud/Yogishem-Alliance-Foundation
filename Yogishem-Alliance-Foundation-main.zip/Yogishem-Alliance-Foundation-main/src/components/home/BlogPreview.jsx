import { Link } from "react-router-dom";
import Reveal from "../ui/Reveal.jsx";
import SectionHeading from "../ui/SectionHeading.jsx";
import Button from "../ui/Button.jsx";
import Img from "../ui/Img.jsx";
import { posts } from "../../data/blog.js";

export function PostCard({ p }) {
  return (
    <Link to={`/blog/${p.slug}`} className="group block">
      <div className="overflow-hidden rounded-3xl">
        <Img src={p.image} alt="" className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-105" />
      </div>
      <p className="mt-4 flex items-center gap-2 text-sm text-ink/60">
        <span className="rounded-full bg-plum-50 px-2.5 py-0.5 font-medium text-plum-700">{p.category}</span>
        <time>{p.date}</time>
      </p>
      <h3 className="mt-2 font-serif text-xl font-semibold text-ink transition-colors group-hover:text-plum-700">{p.title}</h3>
      <p className="mt-2 leading-relaxed text-ink/70">{p.excerpt}</p>
    </Link>
  );
}

export default function BlogPreview() {
  return (
    <section className="bg-plum-50/50 py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <SectionHeading eyebrow="Blog" title="Stories from" highlight="our centres" align="left" />
          <Button to="/blog" variant="outline" arrow className="self-start sm:self-auto">View all posts</Button>
        </div>
        <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {posts.slice(0, 3).map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.08} as="article" className={i === 2 ? "sm:col-span-2 lg:col-span-1" : ""}>
              <PostCard p={p} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

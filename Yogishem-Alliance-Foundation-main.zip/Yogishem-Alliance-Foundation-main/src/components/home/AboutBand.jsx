import { Heart } from "lucide-react";
import Reveal from "../ui/Reveal.jsx";
import Button from "../ui/Button.jsx";
import Icon from "../ui/Icon.jsx";
import { aboutStats } from "../../data/site.js";

export default function AboutBand() {
  return (
    <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <Reveal className="relative overflow-hidden rounded-3xl bg-forest-700 text-white">
        <Heart className="absolute bottom-4 left-1/2 h-24 w-24 text-white/5" aria-hidden />
        <div className="grid gap-8 p-6 sm:p-10 lg:grid-cols-[170px_minmax(0,1.25fr)_minmax(0,1fr)] lg:items-center lg:gap-10">
          <div className="flex items-center gap-4 lg:flex-col lg:text-center">
            <img src="/images/yaf-logo.png" alt="" loading="lazy" className="h-20 w-20 rounded-full border-4 border-white/90 bg-white sm:h-24 sm:w-24" />
            <div>
              <h2 className="font-serif text-3xl font-bold">About YAF</h2>
              <p className="text-sm text-white/70">Yogishem Alliance Foundation</p>
            </div>
          </div>
          <div className="lg:border-r lg:border-white/15 lg:pr-10">
            <p className="max-w-xl leading-relaxed text-white/85">
              <strong className="text-white">Yogishem Alliance Foundation (YAF)</strong> is a non-profit organization working towards a better future for underprivileged children of construction workers. We focus on education, health, hygiene, and overall well-being through community engagement and support programs.
            </p>
            <Button to="/about" variant="white" arrow className="mt-6 px-5 py-2.5 text-sm">Know More About Us</Button>
          </div>
          <ul className="grid grid-cols-3 divide-x divide-white/15 rounded-2xl bg-white/5 py-5 lg:bg-transparent lg:py-0">
            {aboutStats.map((s) => (
              <li key={s.label} className="flex flex-col items-center px-3 text-center sm:px-6">
                <Icon name={s.icon} className="mb-3 h-8 w-8 text-white/90" strokeWidth={1.5} />
                <span className="text-base font-semibold leading-tight sm:text-xl">{s.value}</span>
                <span className="text-xs text-white/70 sm:text-sm">{s.label}</span>
              </li>
            ))}
          </ul>
        </div>
      </Reveal>
    </section>
  );
}

import { useEffect, useState } from "react";
import { m, AnimatePresence, useReducedMotion } from "framer-motion";
import Reveal from "../ui/Reveal.jsx";
import { supporters } from "../../data/home.js";

const PER_PAGE = 4;

function LogoTile({ s }) {
  return (
    <div className="flex aspect-[3/2] items-center justify-center rounded-2xl border border-plum-100 bg-white p-4 transition-shadow hover:shadow-md">
      {s.logo ? (
        <img src={s.logo} alt={s.name} loading="lazy" className="max-h-16 w-auto object-contain" />
      ) : (
        <div className="text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-plum-600 to-forest-600 font-serif text-lg font-bold text-white">{s.short}</span>
          <span className="mt-2 block text-xs font-medium text-ink/70">{s.name}</span>
        </div>
      )}
    </div>
  );
}

export default function Supporters() {
  const pages = Math.ceil(supporters.length / PER_PAGE);
  const [page, setPage] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (paused || reduce || pages < 2) return;
    const t = setInterval(() => setPage((p) => (p + 1) % pages), 3500);
    return () => clearInterval(t);
  }, [paused, reduce, pages]);

  const visible = supporters.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);

  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24 lg:px-8">
      <div className="grid items-center gap-10 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
        <Reveal>
          <span className="inline-block rounded-full bg-plum-100 px-3 py-1 text-xs font-semibold text-plum-700 sm:text-sm">Our supporters</span>
          <h2 className="mt-3 font-serif text-3xl font-bold text-plum-700 sm:text-4xl">Deep Appreciation for Your Support</h2>
          <span className="mt-3 inline-block rounded-lg bg-plum-700 px-3 py-1 text-sm font-medium text-white">From the Beneficiary Children</span>
          <p className="mt-5 max-w-lg leading-relaxed text-ink/70">
            To our amazing supporters, we want to say a heartfelt thank you. Your kindness has brought smiles to our children and hope to their families. Because of you, we have nutritious meals, a place to learn, and many more opportunities to grow. Thank you for believing in our mission.
          </p>
        </Reveal>

        <div onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
          <div className="relative min-h-[180px]">
            <AnimatePresence mode="wait">
              <m.ul key={page} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.4 }} className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                {visible.map((s) => <li key={s.name}><LogoTile s={s} /></li>)}
              </m.ul>
            </AnimatePresence>
          </div>
          {pages > 1 && (
            <div className="mt-6 flex justify-center gap-2">
              {Array.from({ length: pages }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setPage(i)}
                  aria-label={`Show supporters page ${i + 1}`}
                  aria-current={page === i}
                  className={`h-2.5 rounded-full transition-all ${page === i ? "w-8 bg-plum-700" : "w-2.5 bg-plum-200 hover:bg-plum-500"}`}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

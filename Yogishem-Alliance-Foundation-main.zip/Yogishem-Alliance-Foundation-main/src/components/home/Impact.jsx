import Reveal from "../ui/Reveal.jsx";
import Img from "../ui/Img.jsx";
import useCountUp from "../../hooks/useCountUp.js";
import { img } from "../../data/images.js";

function KidsDoodle(props) {
  return (
    <svg viewBox="0 0 120 80" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden {...props}>
      <circle cx="35" cy="18" r="10" /><path d="M35 28v26M35 36l-14 10M35 36l22 6M35 54l-10 20M35 54l10 20" />
      <circle cx="85" cy="18" r="10" /><path d="M85 28v26M85 36l14 10M85 36l-22 6M85 54l-10 20M85 54l10 20M72 54h26l-4-20H76z" />
    </svg>
  );
}

export default function Impact() {
  const [ref, count] = useCountUp(100);
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
      <Reveal className="grid overflow-hidden rounded-3xl bg-gradient-to-br from-plum-700 via-plum-800 to-plum-900 text-white shadow-2xl shadow-plum-900/20 md:grid-cols-[1fr_1.1fr]">
        <Img src={img.classroom} alt="Children learning together in a classroom" className="h-56 w-full object-cover md:h-full" />
        <div className="relative p-8 sm:p-10 lg:p-14">
          <KidsDoodle className="absolute bottom-6 right-6 hidden h-20 w-28 text-white/80 sm:block" />
          <h2 className="font-serif text-2xl font-semibold sm:text-3xl">Our current impact</h2>
          <p className="mt-3 text-lg text-white/80 sm:text-xl">Currently enriching the lives of approximately</p>
          <p ref={ref} className="mt-4 text-6xl font-semibold tracking-tight sm:text-7xl">
            {count}<span className="ml-3 text-3xl font-medium sm:text-4xl">children</span>
          </p>
          <span className="mt-3 block h-1.5 w-24 rounded-full bg-sun" aria-hidden />
        </div>
      </Reveal>
    </section>
  );
}

import { Link } from "react-router-dom";
import { m } from "framer-motion";
import { ChevronRight } from "lucide-react";
import Img from "./Img.jsx";

const ease = [0.22, 1, 0.36, 1];

// Shared hero for inner pages: breadcrumb + title on the left, photo card on the right.
export default function PageHero({ crumb, title, highlight, text, image, children }) {
  return (
    <section className="relative overflow-hidden bg-plum-900 text-white">
      <div className="absolute inset-0 opacity-40 [background:radial-gradient(60%_80%_at_85%_20%,var(--color-plum-500),transparent_70%),radial-gradient(50%_60%_at_0%_100%,var(--color-forest-700),transparent_70%)]" aria-hidden />
      <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 sm:py-20 lg:grid-cols-[1.1fr_1fr] lg:px-8 lg:py-24">
        <m.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease }}>
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-sm text-white/60">
            <Link to="/" className="hover:text-white">Home</Link>
            <ChevronRight className="h-4 w-4" />
            <span className="text-white/90">{crumb}</span>
          </nav>
          <h1 className="mt-5 font-serif text-4xl font-bold leading-[1.1] sm:text-5xl lg:text-6xl">
            {title} {highlight && <span className="text-plum-200">{highlight}</span>}
          </h1>
          {text && <p className="mt-5 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">{text}</p>}
          {children && <div className="mt-8">{children}</div>}
        </m.div>
        {image && (
          <m.div
            className="relative"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, ease, delay: 0.1 }}
          >
            <div className="absolute -inset-3 rotate-2 rounded-[2rem] bg-white/10" aria-hidden />
            <Img src={image} alt="" eager className="relative aspect-[4/3] w-full rounded-[1.75rem] object-cover shadow-2xl" />
          </m.div>
        )}
      </div>
      <svg className="relative -mb-px block h-8 w-full text-white sm:h-12" viewBox="0 0 1440 48" preserveAspectRatio="none" aria-hidden>
        <path fill="currentColor" d="M0 48h1440V0c-240 32-480 48-720 48S240 32 0 0v48z" />
      </svg>
    </section>
  );
}

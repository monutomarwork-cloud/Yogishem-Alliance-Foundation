// Simple accessible form field used by all forms.
export default function Field({ label, name, type = "text", error, as = "input", options, className = "", ...rest }) {
  const base = `mt-1.5 w-full rounded-xl border bg-white px-4 py-3 text-ink outline-none transition-colors placeholder:text-ink/40 focus:border-plum-500 focus:ring-4 focus:ring-plum-100 ${
    error ? "border-red-400" : "border-plum-100"
  }`;
  return (
    <label className={`block text-sm font-medium text-ink/80 ${className}`}>
      {label}
      {as === "textarea" ? (
        <textarea name={name} rows={4} className={base} aria-invalid={!!error} {...rest} />
      ) : as === "select" ? (
        <select name={name} className={base} aria-invalid={!!error} {...rest}>
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input name={name} type={type} className={base} aria-invalid={!!error} {...rest} />
      )}
      {error && <span className="mt-1 block text-xs text-red-600">{error}</span>}
    </label>
  );
}

import Reveal from "./Reveal.jsx";

export default function SectionHeading({ eyebrow, title, highlight, text, align = "center", light = false, className = "" }) {
  const center = align === "center";
  return (
    <Reveal className={`${center ? "mx-auto text-center" : ""} max-w-3xl ${className}`}>
      {eyebrow && (
        <span className={`inline-block rounded-full px-3 py-1 text-xs font-semibold sm:text-sm ${light ? "bg-white/15 text-white" : "bg-plum-100 text-plum-700"}`}>
          {eyebrow}
        </span>
      )}
      <h2 className={`mt-3 font-serif text-3xl font-bold leading-tight sm:text-4xl lg:text-[2.6rem] ${light ? "text-white" : "text-ink"}`}>
        {title} {highlight && <span className={light ? "text-plum-200" : "text-plum-700"}>{highlight}</span>}
      </h2>
      {text && <p className={`mt-3 text-base leading-relaxed sm:text-lg ${light ? "text-white/75" : "text-ink/65"}`}>{text}</p>}
    </Reveal>
  );
}

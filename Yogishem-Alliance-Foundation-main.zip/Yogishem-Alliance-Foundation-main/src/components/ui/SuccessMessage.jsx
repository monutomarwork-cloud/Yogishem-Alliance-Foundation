import { m } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

export default function SuccessMessage({ title, text, onReset, resetLabel = "Send another" }) {
  return (
    <m.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center py-10 text-center" role="status">
      <CheckCircle2 className="h-14 w-14 text-forest-600" />
      <h3 className="mt-4 font-serif text-2xl font-bold text-ink">{title}</h3>
      <p className="mt-2 max-w-sm text-ink/70">{text}</p>
      {onReset && <button type="button" onClick={onReset} className="mt-6 font-semibold text-plum-700 hover:underline">{resetLabel}</button>}
    </m.div>
  );
}

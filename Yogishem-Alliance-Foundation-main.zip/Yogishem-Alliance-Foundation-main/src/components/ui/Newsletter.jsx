import { useState } from "react";
import { Send } from "lucide-react";
import Reveal from "./Reveal.jsx";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle");

  const submit = (e) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setStatus("error");
    // TODO: connect to your email service (Mailchimp, Brevo, your API…)
    setStatus("done");
    setEmail("");
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
      <Reveal className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-plum-700 to-plum-900 px-6 py-12 text-center text-white sm:px-12">
        <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-white/5" aria-hidden />
        <h2 className="relative font-serif text-3xl font-bold sm:text-4xl">Get stories from Nanihal in your inbox</h2>
        <p className="relative mx-auto mt-3 max-w-lg text-white/75">One email a month. Updates from our centres, upcoming events and ways to help.</p>
        {status === "done" ? (
          <p className="relative mt-8 font-semibold text-sun" role="status">Subscribed. Look out for our next update.</p>
        ) : (
          <form onSubmit={submit} noValidate className="relative mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row">
            <label className="flex-1">
              <span className="sr-only">Email address</span>
              <input type="email" value={email} onChange={(e) => { setEmail(e.target.value); setStatus("idle"); }} placeholder="you@example.com" className="w-full rounded-xl bg-white px-4 py-3 text-ink outline-none focus:ring-4 focus:ring-white/30" />
            </label>
            <button className="inline-flex items-center justify-center gap-2 rounded-xl bg-sun px-6 py-3 font-semibold text-ink hover:bg-amber-300"><Send className="h-4 w-4" /> Subscribe</button>
          </form>
        )}
        {status === "error" && <p className="relative mt-2 text-sm text-amber-200">Enter a valid email address, like name@example.com.</p>}
      </Reveal>
    </section>
  );
}

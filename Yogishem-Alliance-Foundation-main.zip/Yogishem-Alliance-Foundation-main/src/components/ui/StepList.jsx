import Reveal from "./Reveal.jsx";

// Numbered process steps — used only where content is a real sequence.
export default function StepList({ steps, light = false }) {
  return (
    <ol className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {steps.map((s, i) => (
        <Reveal as="li" key={s.title} delay={i * 0.08} className="relative">
          {i < steps.length - 1 && (
            <span className={`absolute left-12 right-0 top-6 hidden h-px border-t-2 border-dashed lg:block ${light ? "border-white/25" : "border-plum-200"}`} aria-hidden />
          )}
          <span className={`relative grid h-12 w-12 place-items-center rounded-2xl font-serif text-lg font-bold ${light ? "bg-white text-plum-800" : "bg-plum-700 text-white"}`}>
            {i + 1}
          </span>
          <h3 className={`mt-4 font-semibold ${light ? "text-white" : "text-ink"}`}>{s.title}</h3>
          <p className={`mt-1 text-sm leading-relaxed ${light ? "text-white/70" : "text-ink/65"}`}>{s.text}</p>
        </Reveal>
      ))}
    </ol>
  );
}

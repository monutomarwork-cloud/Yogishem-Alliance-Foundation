import { useEffect, useState } from "react";

// Lazy image with automatic fallback if a remote (third-party) URL fails.
export default function Img({ src, alt = "", className = "", fallback = "/images/hero-children.jpg", eager = false, ...rest }) {
  const [current, setCurrent] = useState(src);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => setCurrent(src), [src]);

  return (
    <img
      src={current}
      alt={alt}
      loading={eager ? "eager" : "lazy"}
      decoding="async"
      onLoad={() => setLoaded(true)}
      onError={() => current !== fallback && setCurrent(fallback)}
      className={`bg-plum-100 transition-opacity duration-500 ${loaded ? "opacity-100" : "opacity-0"} ${className}`}
      {...rest}
    />
  );
}

import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const styles = {
  primary: "bg-plum-700 text-white shadow-lg shadow-plum-700/25 hover:bg-plum-800",
  outline: "border-2 border-plum-200 bg-white text-plum-700 hover:border-plum-700",
  white: "bg-white text-plum-800 hover:bg-plum-50",
};

export default function Button({ to, href, variant = "primary", arrow = false, icon: IconC, children, className = "", ...rest }) {
  const cls = `group inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3 font-semibold transition-colors ${styles[variant]} ${className}`;
  const inner = (
    <>
      {IconC && <IconC className="h-4 w-4 fill-current" />}
      {children}
      {arrow && <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />}
    </>
  );
  if (to) return <Link to={to} className={cls} {...rest}>{inner}</Link>;
  if (href) return <a href={href} className={cls} {...rest}>{inner}</a>;
  return <button className={cls} {...rest}>{inner}</button>;
}

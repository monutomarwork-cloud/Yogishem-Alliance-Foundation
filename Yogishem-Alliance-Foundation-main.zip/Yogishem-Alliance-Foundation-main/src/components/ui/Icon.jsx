import {
  Users, Heart, BookOpen, Library, Backpack, Soup, ShowerHead, GraduationCap, HeartPulse, Megaphone, Sprout,
  ShieldCheck, HeartHandshake, Sparkles, BadgeCheck, BookOpenText, Utensils, Stethoscope, Palette, Camera,
  Building2, Landmark, Gift, Target, Receipt, HandHeart,
} from "lucide-react";

// Lets data files refer to icons by name (handy when content later comes from an API/CMS).
const map = {
  Users, Heart, BookOpen, Library, Backpack, Soup, ShowerHead, GraduationCap, HeartPulse, Megaphone, Sprout,
  ShieldCheck, HeartHandshake, Sparkles, BadgeCheck, BookOpenText, Utensils, Stethoscope, Palette, Camera,
  Building2, Landmark, Gift, Target, Receipt, HandHeart,
};

export default function Icon({ name, ...props }) {
  const C = map[name] || Heart;
  return <C {...props} />;
}

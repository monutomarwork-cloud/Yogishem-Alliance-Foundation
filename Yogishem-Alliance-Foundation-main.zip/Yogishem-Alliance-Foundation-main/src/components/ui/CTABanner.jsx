import { HandHeart } from "lucide-react";
import Reveal from "./Reveal.jsx";
import Button from "./Button.jsx";

// Green "Join us" banner from the design — reused across pages with different copy.
export default function CTABanner({
  title = "Join Us Right Now!",
  text = "With your support we can change the system and protect the future of children of laborers.",
  cta = "Become a Volunteer",
  to = "/volunteer",
}) {
  return (
    <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8">
      <Reveal className="relative overflow-hidden rounded-3xl bg-forest-700 px-6 py-8 text-white sm:px-10 sm:py-10">
        <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-white/5" aria-hidden />
        <div className="absolute -bottom-20 left-1/3 h-48 w-48 rounded-full bg-white/5" aria-hidden />
        <div className="relative flex flex-col gap-6 md:flex-row md:items-center">
          <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-white/10">
            <HandHeart className="h-9 w-9 text-sun" strokeWidth={1.6} />
          </div>
          <div className="flex-1">
            <h2 className="font-serif text-2xl font-bold sm:text-3xl">{title}</h2>
            <p className="mt-1 max-w-xl text-white/80">{text}</p>
          </div>
          <Button to={to} variant="white" arrow className="self-start md:self-auto">{cta}</Button>
        </div>
      </Reveal>
    </section>
  );
}

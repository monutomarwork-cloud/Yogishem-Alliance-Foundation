import { useEffect } from "react";

export default function usePageTitle(title) {
  useEffect(() => {
    document.title = title ? `${title} | Yogishem Alliance Foundation` : "Yogishem Alliance Foundation | Nurturing Futures, Transforming Lives";
  }, [title]);
}

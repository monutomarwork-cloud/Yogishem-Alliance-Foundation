import { useState } from "react";

// Tiny form helper: values, per-field errors, and a submit handler.
// rules: { fieldName: (value, allValues) => "error message" | "" }
export default function useForm(initial, rules = {}) {
  const [values, setValues] = useState(initial);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | sending | done

  const bind = (name) => ({
    name,
    value: values[name],
    error: errors[name],
    onChange: (e) => {
      const v = e.target.type === "checkbox" ? e.target.checked : e.target.value;
      setValues((s) => ({ ...s, [name]: v }));
      if (errors[name]) setErrors((s) => ({ ...s, [name]: "" }));
    },
  });

  const handleSubmit = (onValid) => async (e) => {
    e.preventDefault();
    const next = {};
    for (const [k, fn] of Object.entries(rules)) {
      const msg = fn(values[k], values);
      if (msg) next[k] = msg;
    }
    setErrors(next);
    if (Object.keys(next).length) return;
    setStatus("sending");
    await onValid(values); // TODO: replace with your API call
    setStatus("done");
  };

  const reset = () => {
    setValues(initial);
    setErrors({});
    setStatus("idle");
  };

  return { values, setValues, errors, bind, handleSubmit, status, reset };
}

export const required = (label) => (v) => (String(v ?? "").trim() ? "" : `Enter your ${label}.`);
export const email = (v) => (/^\S+@\S+\.\S+$/.test(v || "") ? "" : "Enter a valid email address, like name@example.com.");
export const phone = (v) => (/^[+\d][\d\s-]{8,}$/.test(v || "") ? "" : "Enter a valid phone number with at least 10 digits.");
export const fakeSend = () => new Promise((r) => setTimeout(r, 700));

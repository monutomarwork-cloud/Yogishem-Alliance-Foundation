// Third-party images (Unsplash, free to use). Swap any URL for your own photos.
// If a remote image ever fails to load, <Img> falls back to a local photo automatically.
const u = (id, w = 1200) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=70`;

export const img = {
  kidsSmiling: u("photo-1488521787991-ed7bbaae773c"),
  paintedHands: u("photo-1503454537195-1dcabb73ffb9", 900),
  classroom: u("photo-1509062522246-3755977927d7"),
  childReading: u("photo-1544717305-2782549b5136", 900),
  kidsPencils: u("photo-1497486751825-1233686d5d80", 900),
  childPlaying: u("photo-1516627145497-ae6968895b74", 900),
  volunteers: u("photo-1559027615-cd4628902d4a"),
  handsTogether: u("photo-1469571486292-0ba58a3f068b"),
  donationBox: u("photo-1593113598332-cd288d649433"),
  meal: u("photo-1488459716781-31db52582fe9", 900),
  books: u("photo-1503676260728-1c00da094a0b", 900),
  toys: u("photo-1587654780291-39c9404d746b", 900),
  teamMeeting: u("photo-1522071820081-009f0129c71c"),
  community: u("photo-1531206715517-5c0ba140b2b8"),
  portrait1: u("photo-1573496359142-b8d87734a5a2", 500),
  portrait2: u("photo-1507003211169-0a1dd7228f2d", 500),
  portrait3: u("photo-1580489944761-15a19d654956", 500),
  portrait4: u("photo-1500648767791-00dcc994a43e", 500),

  // Local photos from your /public/images folder
  localHero: "/images/hero-children.jpg",
  localCentre: "/images/nanihal-centre.jpg",
  logo: "/images/yaf-logo.png",
};

export const navLinks = [
  { label: "Home", to: "/" },
  { label: "About Us", to: "/about" },
  { label: "Nanihal", to: "/nanihal" },
  { label: "Gallery", to: "/gallery" },
  { label: "Blog", to: "/blog" },
  {
    label: "Get Involved",
    children: [
      { label: "Volunteer with us", to: "/volunteer", note: "Teach, mentor or help at a centre" },
      { label: "Partner with us", to: "/partner", note: "CSR and builder partnerships" },
      { label: "Events", to: "/events", note: "Drives, camps and celebrations" },
      { label: "Donate", to: "/donate", note: "Sponsor a child's care and learning" },
    ],
  },
  { label: "Contact Us", to: "/contact" },
];

export const contact = {
  address: "Noida, Uttar Pradesh, India",
  phone: "+91 99765 43210",
  phoneHref: "tel:+919976543210",
  email: "yafoundation@gmail.com",
  hours: "Mon – Sat, 9:30 am – 6:00 pm",
  mapQuery: "Noida, Uttar Pradesh",
};

export const socials = [
  { name: "LinkedIn", href: "https://linkedin.com", icon: "linkedin" },
  { name: "Instagram", href: "https://instagram.com", icon: "instagram" },
  { name: "YouTube", href: "https://youtube.com", icon: "youtube" },
  { name: "Facebook", href: "https://facebook.com", icon: "facebook" },
  { name: "X", href: "https://x.com", icon: "x" },
];

export const aboutStats = [
  { icon: "Users", value: "100+", label: "Children reached" },
  { icon: "Heart", value: "Community", label: "focused" },
  { icon: "BookOpen", value: "Education", label: "& well-being" },
];

import { img } from "./images.js";

export const supportItems = [
  { icon: "Library", title: "Providing books, stationery", text: "Essential learning materials for every child", tint: "amber" },
  { icon: "Backpack", title: "School bag", text: "Helping them step towards a brighter future", tint: "green" },
  { icon: "Soup", title: "Healthy food support", text: "Nutritious meals for a healthier tomorrow", tint: "pink" },
  { icon: "ShowerHead", title: "Accessible toilets", text: "Clean and safe sanitation facilities", tint: "blue" },
  { icon: "GraduationCap", title: "Dedicated teachers and caretakers", text: "Caring mentors for guidance and support", tint: "amber" },
  { icon: "HeartPulse", title: "Health and hygiene facilities", text: "Regular health checkups and hygiene practices", tint: "blue" },
  { icon: "Megaphone", title: "General awareness programs", text: "Building knowledge for a better future", tint: "pink" },
  { icon: "Sprout", title: "Supportive environment for growth", text: "A safe and nurturing space to learn and thrive", tint: "green" },
];

export const galleryCategories = ["All", "Activities", "Children", "Events", "Community", "Facilities"];

export const galleryItems = [
  { id: 1, src: img.localCentre, cat: "Facilities", caption: "Our first Nanihal centre at the worksite" },
  { id: 2, src: img.kidsPencils, cat: "Activities", caption: "Colouring and early writing practice" },
  { id: 3, src: img.localHero, cat: "Children", caption: "Morning circle time" },
  { id: 4, src: img.community, cat: "Community", caption: "Parents' meet with the site workers" },
  { id: 5, src: img.childReading, cat: "Children", caption: "Quiet reading corner" },
  { id: 6, src: img.volunteers, cat: "Events", caption: "Volunteer drive, spring 2026" },
  { id: 7, src: img.meal, cat: "Facilities", caption: "Fresh fruit and cooked meals every day" },
  { id: 8, src: img.childPlaying, cat: "Activities", caption: "Outdoor play and movement games" },
  { id: 9, src: img.classroom, cat: "Activities", caption: "Group learning session" },
  { id: 10, src: img.handsTogether, cat: "Community", caption: "Hand in hand with local partners" },
  { id: 11, src: img.toys, cat: "Facilities", caption: "Learning toys donated by supporters" },
  { id: 12, src: img.kidsSmiling, cat: "Events", caption: "Children's Day celebration" },
];

// Replace `logo` with an image path (e.g. "/images/partners/csr.png") when you have partner logos.
export const supporters = [
  { name: "Swachh Bharat Mission", short: "SBM", logo: null },
  { name: "Government of Uttar Pradesh", short: "UP", logo: null },
  { name: "Noida Authority", short: "NA", logo: null },
  { name: "Holistic Builders", short: "HB", logo: null },
  { name: "Green Habitat Group", short: "GH", logo: null },
  { name: "Bright Minds Trust", short: "BM", logo: null },
];

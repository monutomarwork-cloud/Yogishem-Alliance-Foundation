export const faqs = {
  nanihal: [
    { q: "Which children can join Nanihal?", a: "Children aged 2 to 8 whose parents work on construction sites near our centres. There is no fee." },
    { q: "What are the centre timings?", a: "Our centres run from 8:00 am to 5:00 pm, Monday to Saturday, matching typical site shifts." },
    { q: "Do children continue to regular school?", a: "Yes. We prepare older children for primary school and help families with admission to nearby government schools." },
    { q: "What happens when a site project ends?", a: "We help families find a centre near their next site, and share each child's health and learning records." },
  ],
  volunteer: [
    { q: "Do I need teaching experience?", a: "No. We give every volunteer an orientation and pair you with an experienced caretaker." },
    { q: "What is the minimum commitment?", a: "We ask for at least two sessions a month for three months, so children can build a relationship with you." },
    { q: "Is there an age limit?", a: "On-site volunteers must be 18 or older. Younger students can help with drives and events alongside a guardian." },
    { q: "Will I get a certificate?", a: "Yes, after 20 hours of volunteering we issue a certificate of service." },
  ],
  contact: [
    { q: "Can I visit a Nanihal centre?", a: "Yes, visits are welcome by appointment. Please contact us at least 2 days in advance so we can arrange it safely." },
    { q: "How can I donate items?", a: "Email or call us with what you'd like to give. We'll share a list of current needs and drop-off points." },
    { q: "How quickly do you reply?", a: "We reply to all messages within 2 working days." },
  ],
  donate: [
    { q: "Is my donation tax deductible?", a: "Yes. Donations are eligible for deduction under Section 80G of the Income Tax Act. Add your PAN to receive an 80G receipt." },
    { q: "Can I donate monthly?", a: "Yes. Choose 'Monthly' on the form. Monthly gifts help us plan meals and staffing with confidence." },
    { q: "How will I know my donation made a difference?", a: "Every donor receives a receipt by email and our half-yearly impact update." },
    { q: "Can I donate from outside India?", a: "We can currently accept donations only from Indian bank accounts and cards. Please contact us for other options." },
  ],
};

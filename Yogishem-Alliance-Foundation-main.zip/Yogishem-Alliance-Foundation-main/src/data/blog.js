import { img } from "./images.js";

export const blogCategories = ["All", "Stories", "Health", "Education", "Partnerships"];

export const posts = [
  {
    slug: "a-day-at-a-nanihal-centre",
    title: "A day at a Nanihal centre",
    excerpt: "From morning prayers to afternoon naps — what a regular day looks like for the children on site.",
    category: "Stories",
    date: "12 Sep 2026",
    readTime: "5 min read",
    image: img.localCentre,
    author: "Team YAF",
    featured: true,
    body: [
      { type: "p", text: "The first children arrive before 8 am, often carried on a parent's hip as they walk over from the labour camp. By the time the site siren sounds, the centre is full of chatter." },
      { type: "h2", text: "Mornings: settling in" },
      { type: "p", text: "Every day starts with a wash, a glass of milk and circle time. Caretakers check each child for fever, cuts or rashes and note anything unusual in the health register." },
      { type: "quote", text: "When they know what comes next, even the youngest children feel safe enough to learn." },
      { type: "h2", text: "Learning through play" },
      { type: "p", text: "Late mornings are for structured play: sorting shapes, songs in Hindi and English, story cards and early counting. Older children practise letters on slates." },
      { type: "p", text: "After a hot lunch, the little ones nap while older children draw or listen to stories. Parents collect them after their shift ends — clean, fed and full of news about their day." },
    ],
  },
  {
    slug: "why-nutrition-comes-before-the-alphabet",
    title: "Why nutrition comes before the alphabet",
    excerpt: "A hungry child can't learn. How our meal programme supports early education.",
    category: "Health",
    date: "28 Aug 2026",
    readTime: "4 min read",
    image: img.meal,
    author: "Team YAF",
    body: [
      { type: "p", text: "Many children who join Nanihal are underweight for their age. Before we can talk about reading, we need to talk about breakfast." },
      { type: "h2", text: "What we serve" },
      { type: "p", text: "Each child gets milk in the morning, a cooked lunch with dal, rice or roti and vegetables, and seasonal fruit in the afternoon." },
      { type: "p", text: "We weigh and measure every child monthly, so we can see progress and flag children who need a doctor's attention." },
    ],
  },
  {
    slug: "working-with-builders-to-open-safe-spaces",
    title: "Working with builders to open safe spaces",
    excerpt: "How construction companies can host a childcare centre right at the worksite.",
    category: "Partnerships",
    date: "05 Aug 2026",
    readTime: "6 min read",
    image: img.handsTogether,
    author: "Team YAF",
    body: [
      { type: "p", text: "A construction site is no place for a toddler, yet thousands of children spend their days next to mixers and scaffolding because there is nowhere else to go." },
      { type: "h2", text: "How a site centre works" },
      { type: "p", text: "The builder provides a safe, ventilated space and basic utilities. We bring trained caretakers, a curriculum, meals and health checks." },
    ],
  },
  {
    slug: "first-words-early-literacy-at-nanihal",
    title: "First words: early literacy at Nanihal",
    excerpt: "Picture books, songs and slates — how we build a love of reading from age two.",
    category: "Education",
    date: "20 Jul 2026",
    readTime: "4 min read",
    image: img.childReading,
    author: "Team YAF",
    body: [
      { type: "p", text: "Reading starts long before letters. For two-year-olds it starts with naming pictures and joining in with songs." },
      { type: "p", text: "By five or six, most children at Nanihal can recognise letters in two scripts and are ready to join a government primary school." },
    ],
  },
  {
    slug: "hygiene-habits-that-last",
    title: "Hygiene habits that last a lifetime",
    excerpt: "Handwashing songs and toothbrush days — small routines with a big impact on health.",
    category: "Health",
    date: "02 Jul 2026",
    readTime: "3 min read",
    image: img.paintedHands,
    author: "Team YAF",
    body: [
      { type: "p", text: "Clean hands before every meal. It sounds simple, but for children growing up without running water, it's a new habit." },
      { type: "p", text: "We teach through songs and games, and children often take the habits home to their siblings." },
    ],
  },
  {
    slug: "meet-our-volunteers",
    title: "Meet the volunteers who give their Saturdays",
    excerpt: "College students, retired teachers and office workers — the people behind our weekend sessions.",
    category: "Stories",
    date: "18 Jun 2026",
    readTime: "5 min read",
    image: img.volunteers,
    author: "Team YAF",
    body: [
      { type: "p", text: "Every Saturday, a small group of volunteers joins our caretakers for storytelling, art and games." },
      { type: "p", text: "Some come once a month; some have not missed a week in a year. All of them say the children teach them as much as they teach the children." },
    ],
  },
];

export const getPost = (slug) => posts.find((p) => p.slug === slug);

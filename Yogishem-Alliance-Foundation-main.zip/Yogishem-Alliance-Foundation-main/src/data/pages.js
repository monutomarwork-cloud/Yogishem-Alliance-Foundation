import { img } from "./images.js";

// ---------- About ----------
// Placeholder names and dates — replace with your real team and milestones.
export const team = [
  { name: "Anjali Verma", role: "Founder & Director", photo: img.portrait1 },
  { name: "Rohit Mehra", role: "Programme Head, Nanihal", photo: img.portrait2 },
  { name: "Sneha Kapoor", role: "Health & Nutrition Lead", photo: img.portrait3 },
  { name: "Vikram Singh", role: "Partnerships & CSR", photo: img.portrait4 },
];

export const journey = [
  { year: "2023", title: "Foundation registered", text: "Yogishem Alliance Foundation is set up in Noida to support children of construction workers." },
  { year: "2024", title: "First Nanihal centre", text: "Our first worksite centre opens with 20 children, two caretakers and a daily meal." },
  { year: "2025", title: "Health programme added", text: "Monthly health checkups, growth monitoring and hygiene sessions begin." },
  { year: "2026", title: "100 children and growing", text: "More centres, more partners, and around 100 children in our care every day." },
];

export const values = [
  { icon: "ShieldCheck", title: "Safety first", text: "Every child is supervised, protected and cared for in a clean, secure space." },
  { icon: "HeartHandshake", title: "Dignity", text: "We work with families as partners, with respect for their work and their choices." },
  { icon: "Sparkles", title: "Joyful learning", text: "Children learn best through play, curiosity and warm relationships." },
  { icon: "BadgeCheck", title: "Transparency", text: "We report openly on how every rupee is spent and what it achieves." },
];

// ---------- Nanihal ----------
export const dailySchedule = [
  { time: "8:00 am", title: "Arrival & wash", text: "Children arrive with parents, wash up and have a glass of milk." },
  { time: "9:00 am", title: "Circle time", text: "Songs, greetings, and a quick health check by caretakers." },
  { time: "10:00 am", title: "Learning through play", text: "Shapes, colours, numbers, letters and stories." },
  { time: "12:30 pm", title: "Hot lunch", text: "A cooked, balanced meal eaten together." },
  { time: "1:30 pm", title: "Rest & quiet play", text: "Nap time for little ones, drawing and reading for older kids." },
  { time: "4:00 pm", title: "Outdoor play & fruit", text: "Movement games followed by seasonal fruit before pickup." },
];

export const pillars = [
  { icon: "BookOpenText", title: "Early education", text: "Age-appropriate learning that prepares children for primary school." },
  { icon: "Utensils", title: "Nutrition", text: "Milk, cooked meals and fruit every day, with monthly growth tracking." },
  { icon: "Stethoscope", title: "Health", text: "Regular checkups, vaccinations support and referrals when needed." },
  { icon: "ShowerHead", title: "Hygiene", text: "Clean toilets, handwashing routines and personal care habits." },
  { icon: "ShieldCheck", title: "Safe space", text: "A secure, supervised centre away from the hazards of the site." },
  { icon: "Users", title: "Family connect", text: "Parent meetings and awareness sessions on health and schooling." },
];

// ---------- Volunteer ----------
export const volunteerRoles = [
  { icon: "BookOpenText", title: "Teach & read", text: "Lead storytelling, phonics or number games on weekends.", time: "3 hrs / week" },
  { icon: "Palette", title: "Art & music", text: "Run creative sessions — drawing, craft, songs and dance.", time: "2 hrs / week" },
  { icon: "Stethoscope", title: "Health camps", text: "Doctors, nurses and dentists for our monthly checkups.", time: "1 day / month" },
  { icon: "Camera", title: "Skills from home", text: "Design, photography, writing or fundraising support.", time: "Flexible" },
];

export const volunteerSteps = [
  { title: "Apply online", text: "Tell us about yourself and how you'd like to help." },
  { title: "Short call", text: "We'll call to understand your interests and availability." },
  { title: "Orientation", text: "A 2-hour session on child safety and how our centres work." },
  { title: "Start volunteering", text: "Join your first session with one of our caretakers." },
];

export const testimonials = [
  { quote: "I came to teach, but the children taught me patience and joy. Saturdays are the best part of my week.", name: "Priya S.", role: "Volunteer, 1 year" },
  { quote: "Seeing a shy four-year-old sing in front of everyone after two months — that's why I keep coming back.", name: "Arjun K.", role: "Weekend volunteer" },
  { quote: "As a doctor, the health camps let me give back in the most direct way I know.", name: "Dr. Meera N.", role: "Health camp volunteer" },
];

// ---------- Partner ----------
export const partnerModels = [
  { icon: "Building2", title: "Host a site centre", text: "Builders provide a safe space at the worksite; we run the centre end to end.", tag: "For builders" },
  { icon: "Landmark", title: "CSR programme", text: "Fund a centre or a programme area under Schedule VII (education, health).", tag: "For companies" },
  { icon: "Gift", title: "In-kind support", text: "Donate books, bags, meals, toys or hygiene kits for the children.", tag: "For everyone" },
];

export const partnerBenefits = [
  { icon: "Target", title: "Measurable impact", text: "Quarterly reports on attendance, growth, health and learning." },
  { icon: "ShieldCheck", title: "Safer worksites", text: "Fewer children near machinery means fewer accidents on site." },
  { icon: "Users", title: "Happier workforce", text: "Parents work with peace of mind, improving retention." },
  { icon: "Receipt", title: "Tax & compliance", text: "CSR-eligible activities with full documentation and 80G receipts." },
];

export const partnerSteps = [
  { title: "Discovery call", text: "We learn about your site or CSR goals." },
  { title: "Site visit & plan", text: "We assess space and propose a programme and budget." },
  { title: "Agreement", text: "Clear MoU with responsibilities, reporting and timelines." },
  { title: "Launch & report", text: "Centre opens; you receive regular impact updates." },
];

// ---------- Events ----------
export const events = [
  { id: 1, title: "Children's Day celebration", date: "2026-11-14", place: "Nanihal Centre, Sector 150", type: "Celebration", image: img.kidsSmiling, text: "Games, a puppet show and a special lunch for all our children. Volunteers welcome." },
  { id: 2, title: "Winter clothing drive", date: "2026-12-05", place: "Collection points across Noida", type: "Drive", image: img.donationBox, text: "Help us collect sweaters, blankets and warm socks for 100+ children." },
  { id: 3, title: "Monthly health camp", date: "2026-10-18", place: "Nanihal Centre, Sector 150", type: "Health", image: img.childPlaying, text: "Free checkups, growth monitoring and dental screening with partner doctors." },
  { id: 4, title: "Volunteer orientation", date: "2026-10-10", place: "Online (Zoom)", type: "Volunteer", image: img.teamMeeting, text: "A 2-hour introduction for new volunteers on child safety and our programmes." },
  { id: 5, title: "Independence Day at Nanihal", date: "2026-08-15", place: "Nanihal Centre", type: "Celebration", image: img.localHero, text: "Flag hoisting, songs and sweets with children and parents." },
  { id: 6, title: "Book donation week", date: "2026-07-20", place: "Noida", type: "Drive", image: img.books, text: "Over 600 picture books collected for our reading corners." },
];

// ---------- Donate ----------
export const donationTiers = [
  { amount: 500, impact: "School supplies — books, crayons and a slate — for one child" },
  { amount: 1000, impact: "Nutritious meals for one child for a whole month" },
  { amount: 2500, impact: "A health checkup and hygiene kit for five children" },
  { amount: 5000, impact: "Full care and learning for one child for two months" },
];

// Placeholder percentages — replace with your audited figures.
export const fundAllocation = [
  { label: "Early education & materials", value: 38, color: "bg-plum-700" },
  { label: "Nutrition", value: 27, color: "bg-forest-600" },
  { label: "Health & hygiene", value: 20, color: "bg-sun" },
  { label: "Operations & admin", value: 15, color: "bg-plum-200" },
];

export const otherWays = [
  { icon: "Gift", title: "Donate in kind", text: "Books, school bags, toys, clothes or hygiene kits.", to: "/contact" },
  { icon: "Building2", title: "Corporate & CSR", text: "Fund a centre or programme as part of your CSR.", to: "/partner" },
  { icon: "HandHeart", title: "Give your time", text: "Volunteer on weekends or from home.", to: "/volunteer" },
];

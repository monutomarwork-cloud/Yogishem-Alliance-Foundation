# Yogishem Alliance Foundation — Home Page

React 18 + Vite 6 + Tailwind CSS v4 + Framer Motion (loaded via `LazyMotion`, so only ~28 KB gzipped of animation code ships).

## Run it

Requires Node.js 18+ (20 or 22 recommended).

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in /dist
npm run preview    # preview the production build
```

## Project structure

```
public/images/          hero-children.jpg, nanihal-centre.jpg, yaf-logo.png
src/
  data/site.js          ← nav links, "Get Involved" dropdown, stats, blog posts (edit here)
  components/
    Navbar.jsx          sticky nav, active-section highlight, dropdown, mobile drawer
    Hero.jsx            page-load animation sequence
    Nanihal.jsx         "What is Nanihal?" section
    AboutYAF.jsx        green About band with stats
    BlogPreview.jsx     latest blog posts
    Footer.jsx          contact + links (id="contact")
    Reveal.jsx          reusable one-time scroll reveal
  index.css             Tailwind import + brand colours & fonts (@theme)
  App.jsx / main.jsx
```

## Replace before going live

- **Images:** the files in `public/images/` were cropped from the design screenshot and are low
  resolution. Replace them with your original photos using the same file names
  (recommended: hero ~1600px wide, others ~1000px, compressed to WebP/JPG under 250 KB).
- **Contact details** in `Footer.jsx`.
- **Links:** nav items point to on-page anchors (`#about`, `#blog`, …). When you add real pages,
  install `react-router-dom` and swap the `<a href>` tags for `<Link to>`.

## Performance notes

- Framer Motion uses `LazyMotion` + `m` components (smaller bundle than `motion`).
- Only `opacity`/`transform` are animated (GPU-friendly); animations respect the OS
  "reduce motion" setting.
- Below-the-fold images use `loading="lazy"`; the hero image is preloaded.
- React and Framer Motion are split into separate cached vendor chunks.
